<!doctype html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no">
<!-- Favicon -->
<link rel="shortcut icon" href="images/NETSOL-favicon.png" type="image/x-icon">
<link rel="icon" href="images/NETSOL-favicon.png" type="image/x-icon">



	
<title>NETSOL Technologies | Leasing & Asset Finance Software</title>
<meta name='Description' content='NETSOL Technologies provides superior asset finance software solutions & digital enablement solutions for the asset finance & leasing industry worldwide.' />
<meta name='keywords' content='asset finance sotware, leasing software, equipment finance software, equipment finance' />
 
<meta name="msvalidate.01" content="2150321FF6A30335E031217BE4BD0735" />



    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:title" content="Asset Finance and Leasing Software | NETSOL Technologies Inc."/>
    <meta name="twitter:description" content="NETSOL Technologies provides superior software solutions & digital enablement solutions for the asset finance & leasing industry worldwide."/>
    <meta property="twitter:image" content="https://netsoltech.com/images/netsollogo.png"/>
    <meta property="twitter:url" content="https://netsoltech.com/"/>

    <!-- Facebook Card -->
    <meta property="og:locale" content="en_US"/>
    <meta property="fb:app_id" content="729398607510791"/>
    <meta property="og:site_name" content="NETSOL Technologies"/>
    <meta property="og:title" content="Asset Finance and Leasing Software | NETSOL Technologies Inc."/>
    <meta property="og:url" content="https://www.netsoltech.com/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="NETSOL Technologies provides superior software solutions & digital enablement solutions for the asset finance & leasing industry worldwide."/>
    <meta property="og:image" content="https://netsoltech.com/images/netsollogo.png"/>
    <meta itemprop="image" content="https://netsoltech.com/images/netsollogo.png"/>



    
    <link rel="canonical" href="https://www.netsoltech.com/" />

 
<link rel="preload" href="https://netsoltech.com/css/fonts/TisaOT.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://netsoltech.com/css/fonts/eurostileext-reg-webfont.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://netsoltech.com/css/fonts/Akkurat-Bold.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://netsoltech.com/css/fonts/Akkurat-Light.woff2" as="font" type="font/woff2" crossorigin>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131668973-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131668973-1');
</script>
 
<script>
/*$(window).on('beforeunload', function(e) {
  document.cookie = 'Name of your cookie' + '=; expires=Thu, 01-Jan-70 00:00:01 GMT;';
});*/
</script>

<!-- Asked By Ali -->
<!-- <script src="//assets.adobedtm.com/c876840ac68fc41c08a580a3fb1869c51ca83380/satelliteLib-d541862222d154d9946ea8544a72ed2ff0e3d0c8.js"></script> -->

<!-- Global site tag (gtag.js) - Google Ads: 709487809 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-709487809"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-709487809');
</script>

<!-- Conversion tag Script (gtag.js) - Google Ads: 709487809 -->
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-709487809/3cAhCNjjj8ABEMHZp9IC',
      'event_callback': callback
  });
  return false;
}
</script>
 
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWVDSHZ');</script>
<!-- End Google Tag Manager --> 

<script src='https://www.google.com/recaptcha/api.js' defer></script>

<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "a1xcew5law");
</script>
 
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWVDSHZ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<div id="mainWrapper">

<canvas></canvas>
 
<div id="header">
    <div class="container clearfix">
        <div id="mainLogo">
            <a href="/">
                <img src="images/netsol-logo.svg" alt="#" id="mainlogoImg" />
                <img src="images/netsol-logo-white.svg" alt="#" id="mainlogoWhite">
            </a>
        </div>
        <a id="mainMenuLink" data-aos="fade-up" data-aos-duration="500"><label>MENU</label><span></span></a>
                <div id="headerLang">
            <div class="formField darkStyle">
                <div class="formFieldIn">
                    <div class="selectField">
                        <select>
                        	<option selected value="https://netsoltech.com/index">English</option>
                            <option value="https://netsoltech.cn/index">中文</option>
                            <option value="http://th.netsoltech.com/index">Thai</option>
                            <option value="http://id.netsoltech.com/index">Bahasa</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <script>
        $(window).on('load', function(){
            $('#headerLang .selectField .select-items div').on('click', function() {
                itemIndex = $(this).index()
                var itemVal = $('#headerLang select').val();
                window.location.href = itemVal;
            });
        });
        </script>
    </div>
</div>

<a id="windowScrollDown">
    <img src="images/scrollText.svg" alt="#"/>
    <span><img id="scrollDownArrow" src="images/scrollDown.svg" alt="#"/></span>
</a>
<a id="windowScrollUp">
    <img src="images/backToTop.svg" alt="#"/>
</a>
<a id="requestDemo" class="open-model-window" href="#mainRequestDemo">
    <img src="images/requestDemo.svg" alt="#"/>
</a>

<div id="mainMenu" class="hideWhileReady">
    <div class="container">
        <div id="menuLogo">
            <a href="/">
                <img src="images/netsol-logo-white.svg" alt="#" />
            </a>
        </div>
    </div>
    
    <div id="mainNavContactUs">
                <a href="contact-us" class="btn btn-white btn-small">Contact Us</a>
    </div>
    
     

    <a id="menuSmartNav" href="smartnav">Smart<br>Nav</a>     

    <img class="menuVector" id="netsolVector"  src="images/netsolVector.svg"  alt="#" />
    <img class="menuVector" id="ascentVector" src="images/ascentVector.svg" alt="#" />
    <img class="menuVector" id="digitalVector" src="images/digitalVector.svg" alt="#" />
    <img class="menuVector" id="investorsVector" src="images/investorsVector.svg" alt="#" />
    <img class="menuVector" id="innovationVector" src="images/innovationVector.svg" alt="#" />
    <img class="menuVector" id="eventsVector" src="images/eventsVector.svg" alt="#" />
    <img class="menuVector" id="contactUsVector" src="images/contact-usVector.svg" alt="#" />

    <div id="mainMenuNew">
        <div id="mainMenuNewIn">
            <ul id="mainNewUL">
                <li class="active centerItem"><div><span>01</span><a data-vector="#netsolVector" href="/">Home</a></div></li>
                <li class="hasSubMenu ">
                    <div>
                        <span>02</span>
                        <a data-vector="#netsolVector" href="about-us">About Us</a>
                        <ul class="subMenu">
                            <li><a  data-vector="#netsolVector" href="about-us">About NETSOL Technologies</a></li>
                            <li><a data-vector="#netsolVector" class="hashTab" href="about-us#boardOfDirector">Board of Directors</a></li>
                            <li><a data-vector="#netsolVector" class="hashTab" href="about-us#managementTeam">Management Team</a></li>
                            <li><a data-vector="#netsolVector" href="about-us-sr">Social Responsibilities</a></li>
                        </ul>
                    </div>
                </li>
                <li class="hasSubMenu ">
                    <div>
                        <span>03</span>
                        <a data-vector="#ascentVector" href="products">Products</a>
                        <ul class="subMenu">
                            <li><a data-vector="#ascentVector" href="products">Overview</a></li>
                            <li><a data-vector="#ascentVector" href="nfs-ascent">NFS Ascent<sup>&reg;</sup></a></li>
                            <li><a data-vector="#digitalVector" href="nfs-digital">NFS Digital</a></li>
                            <!--<li><a data-vector="#digitalVector" href="nxt">NXT</a>-->
                            
                            <!--<li><a data-vector="#digitalVector" href="https://otozmobility.com/" target="_blank">OTOZ</a>-->
                            
                            <li><a data-vector="#digitalVector" href="https://netsolcloudservices.com" target="_blank">AWS</a>
                            
                            <li><a data-vector="#digitalVector" href="https://flexengine.io" target="_blank">Flex</a>
                            <li><a data-vector="#digitalVector" href="https://hubexengine.io" target="_blank">Hubex</a>
                                                    </ul>
                    </div>                    
                </li>
                <li class="hasSubMenu">
                    <div>
                        <span>04</span>
                        <a data-vector="#investorsVector" href="https://ir.netsoltech.com/">Investors</a>
                        <ul>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/">Overview</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/company-information">Company Information</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/press-releases">News</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/stock-data">Stock Data</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/all-sec-filings">SEC Filings</a></li>
                        </ul>
                    </div>                    
                </li>
                <li class="hasSubMenu ">
                    <div>
                        <span>05</span>
                        <a data-vector="#innovationVector" href="innovation">Innovation</a>
                        <ul>
                            <li><a data-vector="#innovationVector" href="innovation">Overview</a></li>
                            <li><a data-vector="#innovationVector" href="articles">Articles</a></li>
                            <li><a data-vector="#innovationVector" href="downloads">Downloads</a></li>
                            <li><a data-vector="#innovationVector" href="in-the-lab">In the Lab</a></li>
                        </ul>
                    </div>    
                </li>
                <li class="">
                    <div>                
                        <span>06</span>
                        <a data-vector="#eventsVector" href="events">Events</a>
                    </div>                
                </li> 
                <li class="mobileMenuList">
                    <div>                    
                        <span>07</span>
                        <a data-vector="#contactUsVector" href="contact-us.php">Contact Us</a>
                    </div>
                </li>  
                            </ul>

        </div>
    </div>
    
    <!-- <div id="scrollToView">Scroll to View More</div> -->
</div>


    <div id="privacyPolicy">
        <div class="container"><p class="smallText">We use cookies to give you the best experience. By using this site, you agree that we may store and access cookies on your device. <a class="primary-color" href="cookies-policy" target="_blank">Find out more</a> <a id="hidePrivacyPolicy"></a></p></div>
    </div>



 

<link href="dist/jquery.convform.css" rel="stylesheet" type="text/css">

 

<div id="mainHomeLanding"  class="mainSplashMain homeSplash">
    <div class="mainSplash">
        <div class="container">
            <div class="mainSplashIn">
                <h1 class="animateElement" data-animation-type="fadeInUp" data-animation-delay="200">adaptive <span class="magicDisplay">Asset finance software, finance and leasing software</span></h1>
                <h2 class="animateElement" data-animation-type="fadeInUp" data-animation-delay="300">to your business, your growth & the future. <span class="magicDisplay">Asset finance software, finance and leasing software</span></h2>
                <p class="leadText animateElement" data-animation-type="fadeInUp" data-animation-delay="400">Proudly serving the world's top asset finance & leasing companies with smart software technology for over four decades.
 <strong class="magicDisplay">Asset finance software, finance and leasing software</strong></p>
            </div>
        </div>
    </div>
    <a href="#Explore" id="splashExplore" class="animateElement" data-animation-type="fadeInUp" data-animation-delay="500"><span>Explore</span></a>
</div>
<div id="mainSMartNavLanding">
    <div class="mainSplashMain">
        <div class="mainSplash">
            <div id="chatPage" class="container clearfix">
        <div class="float-left width72 mobilechatview">
            <h1 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="100">Welcome to the <span class="blue">NETSOL</span> Tech <br>SmartNav Wizard.</h1>
            <h3 class="mgntop20" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="200">Lets quickly get to the information you require.</h3>
            <div id="chat" class="conv-form-wrapper">
                <form action="" method="GET" class="hidden" style="display:none">
                    <select data-conv-question="What would you like to see?" name="first-question">
                        <option value="company" data-callback="company">ABOUT NETSOL</option>
                        <option value="products">PRODUCTS</option>
                        <option value="netsolio" data-callback="netsolio">INNOVATION</option>
                        <option value="investors" data-callback="investors">INVESTOR RELATIONS</option>
                        <option value="events" data-callback="events">EVENTS</option>
                    </select>
                    
                    <div data-conv-fork="selectfunctions">
                        <input type="text" data-conv-question="NFS Ascent and NFS Digital are a complete product suite for finance and leasing companies globally." data-no-answer="true">
                        <select name="selectbusiness" data-callback="storeState" data-conv-question="Product information has been grouped under asset type and business function. For ease of access, you can also go to the products page if you like.">
                        	
                            <option value="businessfunction">BUSINESS FUNCTION</option>
                            <option value="industry">INDUSTRY</option>
                            <option value="productsoverview">PRODUCTS OVERVIEW</option>
                        </select>
                    </div>
                    
                    <div data-conv-fork="selectbusiness">
                        <div data-conv-case="businessfunction">
                            <select name="businessfunctionlist" data-conv-question="Please click the product you would like to see.">
                            	<option value="back" data-callback="rollback">Back</option>
                                <option value="origination" data-callback="origination">ORIGINATION</option>
                                <option value="credit" data-callback="credit">CREDIT EVALUATION</option>
                                <option value="contract" data-callback="contract">CONTRACT MANAGEMENT</option>
                                <option value="dealer" data-callback="dealer">DEALER ENABLEMENT</option>
                                <option value="customer" data-callback="customer">CUSTOMER SERVICES</option>
                                <option value="collection" data-callback="collection">COLLECTION</option>
                                <option value="wholesale" data-callback="wholesale">WHOLESALE MANAGEMENT</option>
                            </select>
                        </div>
                        <div data-conv-case="industry">
                            <select name="industry" data-conv-question="Please click the product you would like to see.">
                            	<option value="back" data-callback="rollback">Back</option>
                                <option value="autofinance" data-callback="autofinance">AUTO FINANCE</option>
                                <option value="equipmentfinance" data-callback="equipmentfinance">EQUIPMENT FINANCE</option>
                                <option value="assetfinance" data-callback="assetfinance">ASSET FINANCE</option>
                            </select>
                        </div>
                        <div data-conv-case="productsoverview">
                            <select name="industry" data-conv-question="Please click the product you would like to see.">
                                <option value="back" data-callback="rollback">Back</option>
                                <option value="nfsascent" data-callback="nfsascent">NFS ASCENT</option>
                                <option value="nfsdigital" data-callback="nfsdigital">NFS DIGITAL</option>
                            </select>
                        </div>
                    </div>
                    
                    
                    <select name="programmer" data-callback="storeState" data-conv-question="Which of our products for Retail Finance would you like to see?">
                    	<option value="back" data-callback="rollback">Back</option>
                        <option value="omni" data-callback="omni">OMNI POINT OF SALE</option>
                        <option value="cms" data-callback="cms">CMS</option>
                    </select>
                    
                    
                </form>
                
                <div class="moveLeft"></div>
                <div class="moveRight"></div>
                <div style="float:right;">
                	<div class="contact-us-btn" id="contactchatbtn" style="display:none">CONTACT US</div>
                	<div class="contact-us-btn2" id="menuchatbtn" style="display:none">MENU</div>
                </div>
            </div>
        </div>
        <div class="float-right width25 mobileboxview">
            <div id="chatBar" class="chatcards clearfix">
    <div class="card width100 mgn-bot-0 " >
        <div class="cardtitle">
            <img src="images/Press-Releases.svg" alt="#"  class="" />
            <div class="cardtitleplace">
                <h5 class="">Press Releases</h5>
                <h6 class="grey">Released July 17, 2023</h6>
            </div>
        </div>
        <p class="width100 mgntop20 linehgt28 overflowhidden flt-lft "  >
            NETSOL Cloud Services Achieves AWS Lambda Service Delivery Designation
        </p>
        <a href="https://ir.netsoltech.com/press-releases/detail/3193/netsol-cloud-services-achieves-aws-lambda-service-delivery" class="btn btn-small mgntop20">EXPLORE</a>
    </div>
    <div class="card width100 mgntop20 mgn-bot-0 " >
        <div class="cardtitle">
            <img src="images/twitter.svg" alt="#" />
            <div class="cardtitleplace">
                <h5>From Twitter</h5>
                <h6 class="grey">Latest tweet from @netsoltech</h6>
            </div>
        </div>
        <p class="width100 mgntop20 linehgt28 overflowhidden flt-lft">
          NETSOL is excited to be attending the Non-Prime Auto Financing Conference today! Looking forward to gaining valuable insights and networking with industry leaders. Let's explore new opportunities and stay ahead of the curve in the auto financing sector. 
        </p>
        <a href="https://twitter.com/@NETSOLTech" target="_blank" class="btn btn-small mgntop20">EXPLORE</a>
    </div>
    <div class="card width100 mgntop20 mgn-bot-0 " >
    	<div class="cardtitle">
            <img src="images/Events.svg" alt="#" />
            <div class="cardtitleplace">
                <h5  >Events</h5>
                <h6 class="grey" >Where you can find us</h6>
            </div>
        </div>
        <p class="width100 mgntop20 linehgt28 overflowhidden flt-lft">
            Upcoming Event: 
             Leaseurope Annual Convention On <br />04-10-2023        </p>
        <a href="events" class="btn btn-small mgntop20">EXPLORE</a>
    </div>
</div>
         </div>
    </div>
        </div>
    </div>
</div>

 

	<script type="text/javascript" defer="defer">
		var flag=!0,homeCanvas=!0;function homeSplash(){$("#splashExplore").fadeOut(300),$("#mainMenuLink").removeClass("mainMenuLinkwhite"),$("#header.headerWhite #headerLang .formField").addClass("darkStyle"),$("#header").removeClass("headerWhite"),$("#mainHomeLanding").animate({marginTop:"-100vh",opacity:"0"},400),document.getElementById("mainSMartNavLanding").style.display="flex",$("#mainSMartNavLanding").animate({opacity:"1"},400),homeCanvas=!1,canvasAnimation(),setTimeout(function(){$("#header.headerWhite #headerLang .formField").addClass("darkStyle"),$("#header").removeClass("headerWhite active"),document.getElementById("mainHomeLanding").style.display="none"},400)}$(document).ready(function(){$("#windowScrollDown").hide(),$("#requestDemo").hide(),$("body").addClass("homePage"),$("#mainMenuLink").addClass("mainMenuLinkwhite"),$("#header").addClass("headerWhite"),$("#header.headerWhite #headerLang .formField").removeClass("darkStyle")}),$(document).ready(function(){$("#splashExplore").click(function(){homeSplash()})}),$(window).one("DOMMouseScroll mousewheel",function(e){(e.originalEvent.detail>0||e.originalEvent.wheelDelta<0&&!$("#mainMenuLink").hasClass("active"))&&homeSplash()}),$(document).keydown(function(e){40!=e.which||$("#mainMenuLink").hasClass("active")||homeSplash()});
	</script>


 
	<script>
		function showModule(id){
			document.getElementById(id).style.display = 'block';
		}

		function hideModule(id){
			document.getElementById(id).style.display = 'none';
		}
	</script>

	<script src="dist/autosize.min.js" type="text/javascript"></script>
	<script src="dist/jquery.convform.js" type="text/javascript"></script>

	<script>
		function company() {
			$('#chat').hide();
			window.location.href = "about-us";
		}
		function netsolio() {
			$('#chat').hide();
			window.location.href = "innovation";
		}
		function investors() {
			$('#chat').hide();
			window.location.href = "https://ir.netsoltech.com/";
		}
		
		function events() {
			$('#chat').hide();
			window.location.href = "events";
		}
		function contactus() {
			$('#chat').hide();
			window.location.href = "contact-us";
		}
		
		function origination(){
			$('#chat').hide();
			window.location.href = "front-office-enablement";
		}
		function credit(){
			$('#chat').hide();
			window.location.href = "ascent-omni-pos";
		}
		function contract(){
			$('#chat').hide();
			window.location.href = "ascent-cms";
		}
		function dealer(){
			$('#chat').hide();
			window.location.href = "front-office-enablement";
		}
		function customer(){
			$('#chat').hide();
			window.location.href = "digital-self-service-portal#maccount";
		}
		function collection(){
			$('#chat').hide();
			window.location.href = "digital-field-team-enablement#mcollector";
		}
		function wholesale(){
			$('#chat').hide();
			window.location.href = "ascent-wfs";
		}
		
		function autofinance(){
			$('#chat').hide();
			window.location.href = "auto-finance";
		}
		function equipmentfinance(){
			$('#chat').hide();
			window.location.href = "equipment-finance";
		}
		function assetfinance(){
			$('#chat').hide();
			window.location.href = "asset-finance";
		}
		
		function nfsascent(){
			$('#chat').hide();
			window.location.href = "nfs-ascent";
		}
		function nfsdigital(){
			$('#chat').hide();
			window.location.href = "nfs-digital";
		}
		
		function omni(){
			$('#chat').hide();
			window.location.href = "digital-origination-enablement";
		}
		function cms(){
			$('#chat').hide();
			window.location.href = "ascent-cms";
		}
		
		
		
		var rollbackTo = false;
		var originalState = false;
		function storeState(stateWrapper, ready) {
			rollbackTo = stateWrapper.current;
			console.log("storeState called: ",rollbackTo);
		}
		function rollback(stateWrapper, ready) {
			console.log("rollback called: ", rollbackTo, originalState);
			console.log("answers at the time of user input: ", stateWrapper.answers);
			if(rollbackTo!=false) {
				if(originalState==false) {
					originalState = stateWrapper.current.next;
						console.log('stored original state');
				}
				stateWrapper.current.next = rollbackTo;
				console.log('changed current.next to rollbackTo');
			}
		}
		function restore(stateWrapper, ready) {
			if(originalState != false) {
				stateWrapper.current.next = originalState;
				console.log('changed current.next to originalState');
			}
		}

		setTimeout(function(){
			jQuery(function($){
				$('.hidden').show();
				$('.trans-shadow').show();
				//alert("chat is on");
				var convForm = $('#chat').convform();
				//console.log(convForm);
			});
		}, 2000);


		$( document ).ready(function() {

			$('html').addClass('chatBotScrollctrl');
			$('#scrollDownArrow').hide();
			$('#windowScrollDown').hide();
			$('#requestDemo').hide();
			$("#decidetxt").fadeOut("fast");
			$('.trans-shadow').hide();

			//$('.moveRight').show();
			//$('.moveLeft').hide();
			$("div.options").bind("mousewheel DOMMouseScroll", function(e, delta) {
				$(this).scrollLeft(this.scrollLeft + (-delta * 40));
				e.preventDefault();
			});
			// $('.options').mousewheel(function(e, delta) {
			// 	$(this).scrollLeft(this.scrollLeft + (-delta * 40));
			// 	e.preventDefault();
			// });

			var b = null;
			
			$('.moveRight').on( 'mousemove', function(e) {
				//alert('hi');
				var container = $('.options');
				if ((e.pageX - container.offset().left) < container.width() / 2) {
					var direction = function() {
						container.animate( {scrollLeft: '-=600'}, 1000, 'linear', direction );
					}
					if ((b == false) || (b == null)) {
						b = true;
						$('.moveRight').hide();
						$('.moveLeft').show();
						container.stop( true ).animate( {scrollLeft: '-=600'}, 1000, 'linear', direction );
					}
				} 
			}).on ( 'mouseleave', function() {
				var container = $(this).parent();
				container.stop( true );
				b = null;
			});
			
			$('.moveLeft').on( 'mousemove', function(e) {
				//alert('hi');
				var container = $('.options');
				if ((e.pageX - container.offset().left) > container.width() / 2) {
					var direction = function() {
						container.animate( {scrollLeft: '+=600'}, 1000, 'linear', direction );
					}
					if ((b == true) || (b == null)) {
						b = false;
						$('.moveRight').show();
						$('.moveLeft').hide();
						container.stop( true ).animate( {scrollLeft: '+=600'}, 1000, 'linear', direction );
					}
				} 
			}).on ( 'mouseleave', function() {
				var container = $(this).parent();
				container.stop( true );
				b = null;
			});
			
			$('#contactchatbtn').click(function(){
				window.location.href = "contact-us.php";
			});

		});

	</script>

 
 
<script src="js/customScripts.js" type="text/javascript" defer="defer"></script>
<script src="js/canvasScript.js" type="text/javascript" defer="defer"></script>

<!-- <script type="text/javascript">_satellite.pageBottom();</script> -->

<script type="text/javascript"> _linkedin_partner_id = "482123"; window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || []; window._linkedin_data_partner_ids.push(_linkedin_partner_id); </script><script type="text/javascript"> (function(){var s = document.getElementsByTagName("script")[0]; var b = document.createElement("script"); b.type = "text/javascript";b.async = true; b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js"; s.parentNode.insertBefore(b, s);})(); </script> <noscript> <img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=482123&fmt=gif" /> </noscript>

</body>
</html>