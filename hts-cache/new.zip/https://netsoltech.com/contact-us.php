<!doctype html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no">
<!-- Favicon -->
<link rel="shortcut icon" href="images/NETSOL-favicon.png" type="image/x-icon">
<link rel="icon" href="images/NETSOL-favicon.png" type="image/x-icon">



	
<title>NETSOL Technologies | Get In Touch</title>
<meta name='Description' content='Find details & contact us at our headquarters or any of our regional offices situated across the globe.' />
<meta name='keywords' content='asset finance software, finance and leasing software' />
 
<meta name="msvalidate.01" content="2150321FF6A30335E031217BE4BD0735" />



    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:title" content="Asset Finance and Leasing Software | NETSOL Technologies Inc."/>
    <meta name="twitter:description" content="NETSOL Technologies provides superior software solutions & digital enablement solutions for the asset finance & leasing industry worldwide."/>
    <meta property="twitter:image" content="https://netsoltech.com/images/netsollogo.png"/>
    <meta property="twitter:url" content="https://netsoltech.com/"/>

    <!-- Facebook Card -->
    <meta property="og:locale" content="en_US"/>
    <meta property="fb:app_id" content="729398607510791"/>
    <meta property="og:site_name" content="NETSOL Technologies"/>
    <meta property="og:title" content="Asset Finance and Leasing Software | NETSOL Technologies Inc."/>
    <meta property="og:url" content="https://www.netsoltech.com/"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="NETSOL Technologies provides superior software solutions & digital enablement solutions for the asset finance & leasing industry worldwide."/>
    <meta property="og:image" content="https://netsoltech.com/images/netsollogo.png"/>
    <meta itemprop="image" content="https://netsoltech.com/images/netsollogo.png"/>




    <link rel="canonical" href="https://www.netsoltech.com/contact-us" />

 
<link rel="preload" href="https://netsoltech.com/css/fonts/TisaOT.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://netsoltech.com/css/fonts/eurostileext-reg-webfont.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://netsoltech.com/css/fonts/Akkurat-Bold.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="https://netsoltech.com/css/fonts/Akkurat-Light.woff2" as="font" type="font/woff2" crossorigin>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131668973-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131668973-1');
</script>
 
<script>
/*$(window).on('beforeunload', function(e) {
  document.cookie = 'Name of your cookie' + '=; expires=Thu, 01-Jan-70 00:00:01 GMT;';
});*/
</script>

<!-- Asked By Ali -->
<!-- <script src="//assets.adobedtm.com/c876840ac68fc41c08a580a3fb1869c51ca83380/satelliteLib-d541862222d154d9946ea8544a72ed2ff0e3d0c8.js"></script> -->

<!-- Global site tag (gtag.js) - Google Ads: 709487809 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-709487809"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-709487809');
</script>

<!-- Conversion tag Script (gtag.js) - Google Ads: 709487809 -->
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-709487809/3cAhCNjjj8ABEMHZp9IC',
      'event_callback': callback
  });
  return false;
}
</script>
 
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWVDSHZ');</script>
<!-- End Google Tag Manager --> 

<script src='https://www.google.com/recaptcha/api.js' defer></script>

<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "a1xcew5law");
</script>
 
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWVDSHZ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<div id="mainWrapper">

<canvas></canvas>
 
<div id="header">
    <div class="container clearfix">
        <div id="mainLogo">
            <a href="/">
                <img src="images/netsol-logo.svg" alt="#" id="mainlogoImg" />
                <img src="images/netsol-logo-white.svg" alt="#" id="mainlogoWhite">
            </a>
        </div>
        <a id="mainMenuLink" data-aos="fade-up" data-aos-duration="500"><label>MENU</label><span></span></a>
                <div id="headerLang">
            <div class="formField darkStyle">
                <div class="formFieldIn">
                    <div class="selectField">
                        <select>
                        	<option selected value="https://netsoltech.com/contact-us">English</option>
                            <option value="https://netsoltech.cn/contact-us">中文</option>
                            <option value="http://th.netsoltech.com/contact-us">Thai</option>
                            <option value="http://id.netsoltech.com/contact-us">Bahasa</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <script>
        $(window).on('load', function(){
            $('#headerLang .selectField .select-items div').on('click', function() {
                itemIndex = $(this).index()
                var itemVal = $('#headerLang select').val();
                window.location.href = itemVal;
            });
        });
        </script>
    </div>
</div>

<a id="windowScrollDown">
    <img src="images/scrollText.svg" alt="#"/>
    <span><img id="scrollDownArrow" src="images/scrollDown.svg" alt="#"/></span>
</a>
<a id="windowScrollUp">
    <img src="images/backToTop.svg" alt="#"/>
</a>
<a id="requestDemo" class="open-model-window" href="#mainRequestDemo">
    <img src="images/requestDemo.svg" alt="#"/>
</a>

<div id="mainMenu" class="hideWhileReady">
    <div class="container">
        <div id="menuLogo">
            <a href="/">
                <img src="images/netsol-logo-white.svg" alt="#" />
            </a>
        </div>
    </div>
    
    <div id="mainNavContactUs">
                <a href="contact-us" class="btn btn-white btn-small">Contact Us</a>
    </div>
    
     

    <a id="menuSmartNav" href="smartnav">Smart<br>Nav</a>     

    <img class="menuVector" id="netsolVector"  src="images/netsolVector.svg"  alt="#" />
    <img class="menuVector" id="ascentVector" src="images/ascentVector.svg" alt="#" />
    <img class="menuVector" id="digitalVector" src="images/digitalVector.svg" alt="#" />
    <img class="menuVector" id="investorsVector" src="images/investorsVector.svg" alt="#" />
    <img class="menuVector" id="innovationVector" src="images/innovationVector.svg" alt="#" />
    <img class="menuVector" id="eventsVector" src="images/eventsVector.svg" alt="#" />
    <img class="menuVector" id="contactUsVector" src="images/contact-usVector.svg" alt="#" />

    <div id="mainMenuNew">
        <div id="mainMenuNewIn">
            <ul id="mainNewUL">
                <li class=" centerItem"><div><span>01</span><a data-vector="#netsolVector" href="/">Home</a></div></li>
                <li class="hasSubMenu ">
                    <div>
                        <span>02</span>
                        <a data-vector="#netsolVector" href="about-us">About Us</a>
                        <ul class="subMenu">
                            <li><a  data-vector="#netsolVector" href="about-us">About NETSOL Technologies</a></li>
                            <li><a data-vector="#netsolVector" class="hashTab" href="about-us#boardOfDirector">Board of Directors</a></li>
                            <li><a data-vector="#netsolVector" class="hashTab" href="about-us#managementTeam">Management Team</a></li>
                            <li><a data-vector="#netsolVector" href="about-us-sr">Social Responsibilities</a></li>
                        </ul>
                    </div>
                </li>
                <li class="hasSubMenu ">
                    <div>
                        <span>03</span>
                        <a data-vector="#ascentVector" href="products">Products</a>
                        <ul class="subMenu">
                            <li><a data-vector="#ascentVector" href="products">Overview</a></li>
                            <li><a data-vector="#ascentVector" href="nfs-ascent">NFS Ascent<sup>&reg;</sup></a></li>
                            <li><a data-vector="#digitalVector" href="nfs-digital">NFS Digital</a></li>
                            <!--<li><a data-vector="#digitalVector" href="nxt">NXT</a>-->
                            
                            <!--<li><a data-vector="#digitalVector" href="https://otozmobility.com/" target="_blank">OTOZ</a>-->
                            
                            <li><a data-vector="#digitalVector" href="https://netsolcloudservices.com" target="_blank">AWS</a>
                            
                            <li><a data-vector="#digitalVector" href="https://flexengine.io" target="_blank">Flex</a>
                            <li><a data-vector="#digitalVector" href="https://hubexengine.io" target="_blank">Hubex</a>
                                                    </ul>
                    </div>                    
                </li>
                <li class="hasSubMenu">
                    <div>
                        <span>04</span>
                        <a data-vector="#investorsVector" href="https://ir.netsoltech.com/">Investors</a>
                        <ul>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/">Overview</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/company-information">Company Information</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/press-releases">News</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/stock-data">Stock Data</a></li>
                            <li><a data-vector="#investorsVector" href="https://ir.netsoltech.com/all-sec-filings">SEC Filings</a></li>
                        </ul>
                    </div>                    
                </li>
                <li class="hasSubMenu ">
                    <div>
                        <span>05</span>
                        <a data-vector="#innovationVector" href="innovation">Innovation</a>
                        <ul>
                            <li><a data-vector="#innovationVector" href="innovation">Overview</a></li>
                            <li><a data-vector="#innovationVector" href="articles">Articles</a></li>
                            <li><a data-vector="#innovationVector" href="downloads">Downloads</a></li>
                            <li><a data-vector="#innovationVector" href="in-the-lab">In the Lab</a></li>
                        </ul>
                    </div>    
                </li>
                <li class="">
                    <div>                
                        <span>06</span>
                        <a data-vector="#eventsVector" href="events">Events</a>
                    </div>                
                </li> 
                <li class="mobileMenuList">
                    <div>                    
                        <span>07</span>
                        <a data-vector="#contactUsVector" href="contact-us.php">Contact Us</a>
                    </div>
                </li>  
                            </ul>

        </div>
    </div>
    
    <!-- <div id="scrollToView">Scroll to View More</div> -->
</div>



 
<style>
#captcha_code{border:#fff solid 3px !important; padding:5px;}
#captcha_code2{border:#fff solid 3px !important; padding:5px;}
.bgSection{background:none !important; border:#1c72b8 solid 1px !important; color:#1c72b8 !important;}
.bgSection, .bgSection a, .bgSection h1, .bgSection h2, .bgSection h3, .bgSection h4, .checkBoxContainer, .radioContainer{color:#1c72b8;}
.bgSection a:hover{color:#fff !important;}
.getInTouchForm{width:100% !important;}
</style>

<div class="container">

    <div class="breadCrumb">
            <p class="leadText">You are now viewing <a href="/">Home</a><span> / </span><a href="contact-us">Contact Us</a></p>
        </div>
        <div class="pageTitleSection withVector">
        	<img src="images/contactUs-left.svg" alt="#" />
            <div class="pageTitleSectionIn">
                <h1 >Contact Us</h1>
                <p >Please help us to respond better to your query by filling out the relevant form.</p>
            </div>
        </div>
        
        <div class="getInTouchMain clearfix">
            <div class="getInTouch bgSection">
            
                <div class="getInTouchupper clearfix">
                    <div class="text-center clearfix pad-bottom-100 mgntop-vh-15" id="start" style="margin-top:25vh; display:none">
                        <div class="width100">
                            <h3 class="mgntop30 animateElement" data-animation-type="fadeInUp">Request Demo Session</h3>
                            <a class="btn mgntop60 animateElement" data-animation-type="fadeInUp" onClick="showQuestion()">Start</a>
                        </div>
                        
                    </div>
                    
                    <form method="post" name="demorequest" id="demorequest">
                    
                        <div class="text-center padtop0 " id="question1" style="display:block">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">01.Enter your basic information</h4>
                            <div class="getInTouchForm mgntop20">
                                <div class="formField textField darkStyle" id="name">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Name</span>
                                            <input type="text" value="" name="name" onKeyDown="turnwhite('name');">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField textField darkStyle checkemail" id="email">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Email <font id="invalidemail" style="color:#ff0000; display:none;">(Invalid Email)</font></span>
                                            <input type="text" value="" name="email" onKeyDown="turnwhite('email');">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField textField darkStyle" id="designation">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Designation</span>
                                            <input type="text" value="" name="designation" onKeyDown="turnwhite('designation');">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField textField darkStyle" id="companyname" >
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Company Name</span>
                                            <input type="text" value="" name="companyname" onKeyDown="turnwhite('companyname');">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField darkStyle">
                                    <div class="formFieldIn">
                                        <div class="selectField">
                                            <span style="color:#1c72b8">Country</span>
                                            <select name="country" id="country" aria-required="true" aria-invalid="false">
                                                <option value="United Kingdom" selected>United Kingdom</option><option value="Afghanistan">Afghanistan</option><option value="Aland Islands">Aland Islands</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American Samoa">American Samoa</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antarctica">Antarctica</option><option value="Antigua and Barbuda">Antigua and Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Aruba">Aruba</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option><option value="Botswana">Botswana</option><option value="Bouvet Island">Bouvet Island</option><option value="Brazil">Brazil</option><option value="British Indian Ocean Territory">British Indian Ocean Territory</option><option value="British Virgin Islands">British Virgin Islands</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Christmas Island">Christmas Island</option><option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Democratic Republic of Congo">Democratic Republic of Congo</option><option value="Denmark">Denmark</option><option value="Disputed Territory Djibouti">Disputed Territory Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Falkland Islands">Falkland Islands</option><option value="Faroe Islands">Faroe Islands</option><option value="Federated States of Micronesia">Federated States of Micronesia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guyana">French Guyana</option><option value="French Polynesia">French Polynesia</option><option value="French Southern Territories">French Southern Territories</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Iraq-Saudi Arabia Neutral Zone">Iraq-Saudi Arabia Neutral Zone</option><option value="Ireland">Ireland</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macau">Macau</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia Maldives">Malaysia Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="Netherlands">Netherlands</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Niue">Niue</option><option value="Norfolk Island">Norfolk Island</option><option value="North Korea">North Korea</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Palestinian Territories">Palestinian Territories</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Pitcairn Islands">Pitcairn Islands</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="Saint Helena and Dependencies">Saint Helena and Dependencies</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Georgia and South Sandwich Islands">South Georgia and South Sandwich Islands</option><option value="South Korea">South Korea</option><option value="Spain">Spain</option><option value="Spratly Islands">Spratly Islands</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tokelau">Tokelau</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks And Caicos Islands">Turks And Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="US Virgin Islands">US Virgin Islands</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Wallis and Futuna">Wallis and Futuna</option><option value="Western Sahara">Western Sahara</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div> 
                                    </div>
                                </div>
                                <div class="formField textField darkStyle" id="phone">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Phone</span>
                                            <input type="text" value="" name="phone" onKeyDown="turnwhite('phone');">
                                        </label>
                                    </div>
                                </div>
                                <a class="btn btn-small float-left" onClick="showstart()">Previous</a>
                                <a class="btn btn-small float-right" onClick="showNextOption()">Next</a>
                            </div>
                            
                        </div>
                        
                        <div class="text-center pad-bottom-100 padtop0 animateElement" id="question2" style="display:none" data-animation-type="fadeInUp">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">02. What would you like to <br>request demo for?</h4>
                            <br><br>
                            
                            <div class="checkBoxRadioFieldIn darkStyle text-left demo_que">
                                <label class="checkBoxContainer">
                                    NFS Ascent<sup>&reg;</sup> 
                                    <input type="checkbox" value="NFS Ascent" name="demo_for[]" id="nfsascent" class="demo_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    NFS Ascent<sup>&reg;</sup> on Cloud
                                    <input type="checkbox" value="NFS Ascent on Cloud" name="demo_for[]" id="nfsascentcloud" class="demo_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    NFS Digital
                                    <input type="checkbox" value="NFS Digital" name="demo_for[]" id="nfsdigital" class="demo_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    OTOZ
                                    <input type="checkbox" value="OTOZ" name="demo_for[]" id="otoz" class="demo_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    AWS
                                    <input type="checkbox" value="AWS" name="demo_for[]" id="aws" class="demo_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    FLEX
                                    <input type="checkbox" value="FLEX" name="demo_for[]" id="flex" class="demo_class">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <br>
                            <a class="btn btn-small float-left" onClick="showQuestion()">Previous</a>
                            <a class="btn btn-small float-right" onClick="showNextOption2()">Next</a>
                            
                        </div>
                        
                        <div class="text-center pad-bottom-100 padtop0 animateElement" id="question3" style="display:none" data-animation-type="fadeInUp">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">03. What is your type of business?</h4>
                            <br><br>
                            <div class="checkBoxRadioFieldIn darkStyle text-left business_que">
                                <label class="checkBoxContainer">
                                    Retail
                                    <input type="checkbox" value="Retail" name="typeofbusiness[]" id="retail" class="business_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Wholesale
                                    <input type="checkbox" value="Wholesale" id="typeofbusiness[]" name="wholesale" class="business_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Other
                                    <input type="checkbox" value="Otherbiz" id="typeofbusiness[]" name="otherbiz" class="business_class">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <br>
                            <div class="getInTouchForm" style="display:none" id="otherbizfield">
                                <div class="formField darkStyle" >
                                    <div class="formFieldIn" id="nullname">
                                        <label>
                                            <span class="nullname">Type of business</span>
                                            <input type="text" value="" name="otob" id="otob">
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <a class="btn btn-small float-left" onClick="showNextOption()">Previous</a>
                            <a class="btn btn-small float-right" onClick="showNextOption3()">Next</a>
                        </div>
                        
                        <div class="text-center pad-bottom-100 padtop0 animateElement" id="question4" style="display:none" data-animation-type="fadeInUp">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">04. What is your annual contract volume?</h4>
                            <br><br>
                            <div class="checkBoxRadioFieldIn text-left">
                                <label class="radioContainer">
                                    Less than 10,000
                                    <input type="radio" value="Less than 10,000" name="contract_vol[]" id="contractvol" checked>
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radioContainer">
                                    10,000 - 40,000
                                    <input type="radio" value="10,000 - 40,000" name="contract_vol[]" id="contractvol">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radioContainer">
                                    40,000 - 70,000
                                    <input type="radio" value="40,000 - 70,000" name="contract_vol[]" id="contractvol">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radioContainer">
                                    70,000 - 100,000
                                    <input type="radio" value="70,000 - 100,000" name="contract_vol[]" id="contractvol">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radioContainer">
                                    Greater than 100,000
                                    <input type="radio" value="Greater than 100,000" name="contract_vol[]" id="contractvol">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <br>
                            <a class="btn btn-small float-left" onClick="showNextOption2()">Previous</a>
                            <a class="btn btn-small float-right" onClick="showNextOption4()">Next</a>
                        </div>
                        
                        <div class="text-center pad-bottom-100 padtop0 animateElement" id="question5" style="display:none" data-animation-type="fadeInUp">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">05. What type of leases does your company provide?</h4>
                            <br><br>
                            <div class="checkBoxRadioFieldIn text-left lease_que">
                                <label class="checkBoxContainer">
                                    Financial Lease
                                    <input type="checkbox" value="Financial Lease" name="typeofleases[]" id="fl" class="lease_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Operating Lease
                                    <input type="checkbox" value="Operating Lease" name="typeofleases[]" id="ol" class="lease_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Hire Purchase
                                    <input type="checkbox" value="Hire Purchase" name="typeofleases[]" id="hp" class="lease_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Other
                                    <input type="checkbox" value="Other" id="typeofleases[]" name="otherlease" class="lease_class">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <br>
                            <div class="getInTouchForm" style="display:none" id="otherleasefield">
                                <div class="formField darkStyle" >
                                    <div class="formFieldIn" id="nullname">
                                        <label>
                                            <span class="nullname">Type of leases</span>
                                            <input type="text" value="" name="otherleasetype" id="otherleasetype">
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <a class="btn btn-small float-left" onClick="showNextOption3()">Previous</a>
                            <a class="btn btn-small float-right" onClick="showNextOption5()">Next</a>
                        </div>
                        
                        <div class="text-center pad-bottom-100 padtop0 animateElement" id="question6" style="display:none" data-animation-type="fadeInUp">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">06. Which industry does your organization operate in?</h4>
                            <br><br>
                            <div class="checkBoxRadioFieldIn text-left org_que">
                                <label class="checkBoxContainer">
                                    Auto Finance
                                    <input type="checkbox" value="Auto Finance" name="typesoforg[]" id="af" class="org_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Equipment Finance
                                    <input type="checkbox" value="Equipment Finance" name="typesoforg[]" id="ef" class="org_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Big Ticket
                                    <input type="checkbox" value="Big Ticket" name="typesoforg[]" id="bg" class="org_class">
                                    <span class="checkmark"></span>
                                </label>
                                <br>
                                <label class="checkBoxContainer">
                                    Bank or subsidiary
                                    <input type="checkbox" value="Bank or Subsidiary" name="typesoforg[]" id="bs" class="org_class">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="checkBoxContainer">
                                    Other
                                    <input type="checkbox" value="Other" id="typesoforg[]" name="otherorg" class="org_class">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <br>
                            <div class="getInTouchForm" style="display:none" id="otherorgfield">
                                <div class="formField darkStyle" >
                                    <div class="formFieldIn" id="nullname">
                                        <label>
                                            <span class="nullname">Organization Type</span>
                                            <input type="text" value="" name="otherorgtype" id="otherorgtype">
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <a class="btn btn-small float-left" onClick="showNextOption4()">Previous</a>
                            <a class="btn btn-small float-right" onClick="showNextOption6()">Next</a>
                        </div>
                        
                        <div class="text-center pad-bottom-100 animateElement" id="question7" style="display:none;" data-animation-type="fadeInUp">
                            <h3 class="text-left">Request Demo Session</h4>
                            <h4 class="text-left">07. Additional Comments & Submission</h4>
                            <div class="getInTouchForm">
                                <div class="formField textField darkStyle" style="margin-top:30px;">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Please type any additional comments</span>
                                            <input type="text" value="" name="comments" id="comments">
                                        </label>
                                    </div>
                                </div>
                                <div class="checkBoxRadioFieldIn">
                                    <label class="checkBoxContainer" style="text-align:left">
                                        By ticking this box you are consenting to allow NETSOL to contact you from time to time via email about products, services and offers that may be of interest to you.<br><br>
                            <span class="mobileconcent">By submitting your personal details you are consenting to allow NETSOL to process and store your details in line with our privacy policy and to contact you in relation to your submitted enquiry. You can withdraw your marketing consent at any time by sending an email to <a href="mailto:marketing@netsoltech.com" style="text-decoration:underline; color:#1c72b8 !important">marketing@netsoltech.com</a>.
                                <br><br>
                                More information on our processing can be found on <a href="privacy-policy" style="text-decoration:underline; color:#1c72b8 !important">PRIVACY POLICY</a></span>
										<input type="checkbox" value="Yes" name="acceptcheck" id="acceptance">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>    
                                <br>
                                <div class="g-recaptcha" data-sitekey="6LdIlIIjAAAAAOVHRtWn018XvqGbFU-J3JC52SjF"></div>
                            <!--<a class="btn mgntop20" onClick="showNextOption8()">Submit</a>-->
                            <input type="submit" value="Submit" class="btn mgntop20 float-left" />
                            </div> 
                        </div>
                    
                    </form>
                    
                    <div class="text-center pad-bottom-100 animateElement" id="thankyounote" style="display:none; padding-top:225px;" data-animation-type="fadeInUp">
                        <h4></h4>
                        <h3>Thank you! <br> You will be contacted shortly.</h3>
                        <br>
                        <a class="btn mgntop20" onClick="showQuestion()">Submit Another Request</a>
                    </div>
                    
                </div>
                
                <div class="progress_row step_progress" id="demoprogbar" style="display:;">
                    <div class="progress_block step1">
                        <div class="progress_number active">01</div>
                        <div class="progress_bar active"></div>
                    </div>
                    <div class="progress_block step2">
                        <div class="progress_number">02</div>
                        <div class="progress_bar"></div>
                    </div>
                    <div class="progress_block step3">
                        <div class="progress_number">03</div>
                        <div class="progress_bar"></div>
                    </div>
                    <div class="progress_block step4">
                        <div class="progress_number">04</div>
                        <div class="progress_bar"></div>
                    </div>
                    <div class="progress_block step5">
                        <div class="progress_number">05</div>
                        <div class="progress_bar"></div>
                    </div>
                    <div class="progress_block step6">
                        <div class="progress_number">06</div>
                        <div class="progress_bar"></div>
                    </div>
                    <div class="progress_block step7">
                        <div class="progress_number">07</div>
                        <div class="progress_bar"></div>
                    </div>
                </div>
                
            </div>
            
            <div class="getInTouch bgSection">
                
                <div class="getInTouchupper clearfix">
                    <div class="text-center clearfix mgntop-vh-15" id="start-contact" style="margin-top:25vh; display:none;">
                        <div class="width100" id="contactform2">
                            <h3>Get in Touch</h3>
                            <a class="btn mgntop60 " onClick="contactform()">Leave A Message</a>
                        </div>
                    </div>
                    
                    <form method="post" name="contactrequest" id="contactrequest">
                    
                        <div class="text-center" id="contactform" style="display:" >
                            <h3 class="text-left">Contact Form</h4>
                            <h4 class="text-left">01. Enter your basic information</h4>

                            <div class="getInTouchForm mgntop30" >
                                <div class="formField textField darkStyle" id="contactname">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Name</span>
                                            <input type="text" value="" name="contactname" onKeyDown="turnwhite('conname')">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField textField darkStyle checkemail" id="contactemail">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Email <font id="invalidconemail" style="color:#ff0000; display:none;">(Invalid Email)</font></span>
                                            <input type="text" value="" name="contactemail" onKeyDown="turnwhite('conemail')">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField textField darkStyle" id="contactdesignation">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Designation</span>
                                            <input type="text" value="" name="contactdesignation" onKeyDown="turnwhite('condesignation')">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField textField darkStyle" id="contactcompany">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Company Name</span>
                                            <input type="text" value="" name="contactcompany" onKeyDown="turnwhite('concompany')">
                                        </label>
                                    </div>
                                </div>
                                <div class="formField darkStyle">
                                    <div class="formFieldIn">
                                        <div class="selectField">
                                            <span style="color:#1c72b8;">Country</span>
                                            <select name="contactcountry" id="contactcountry" aria-required="true" aria-invalid="false" onChange="turnwhite('concountry')">
                                                <option value="United Kingdom" selected>United Kingdom</option><option value="Afghanistan">Afghanistan</option><option value="Aland Islands">Aland Islands</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American Samoa">American Samoa</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antarctica">Antarctica</option><option value="Antigua and Barbuda">Antigua and Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Aruba">Aruba</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option><option value="Botswana">Botswana</option><option value="Bouvet Island">Bouvet Island</option><option value="Brazil">Brazil</option><option value="British Indian Ocean Territory">British Indian Ocean Territory</option><option value="British Virgin Islands">British Virgin Islands</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Christmas Island">Christmas Island</option><option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Democratic Republic of Congo">Democratic Republic of Congo</option><option value="Denmark">Denmark</option><option value="Disputed Territory Djibouti">Disputed Territory Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Falkland Islands">Falkland Islands</option><option value="Faroe Islands">Faroe Islands</option><option value="Federated States of Micronesia">Federated States of Micronesia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guyana">French Guyana</option><option value="French Polynesia">French Polynesia</option><option value="French Southern Territories">French Southern Territories</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Iraq-Saudi Arabia Neutral Zone">Iraq-Saudi Arabia Neutral Zone</option><option value="Ireland">Ireland</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macau">Macau</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia Maldives">Malaysia Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="Netherlands">Netherlands</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Niue">Niue</option><option value="Norfolk Island">Norfolk Island</option><option value="North Korea">North Korea</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Palestinian Territories">Palestinian Territories</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Pitcairn Islands">Pitcairn Islands</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="Saint Helena and Dependencies">Saint Helena and Dependencies</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Georgia and South Sandwich Islands">South Georgia and South Sandwich Islands</option><option value="South Korea">South Korea</option><option value="Spain">Spain</option><option value="Spratly Islands">Spratly Islands</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tokelau">Tokelau</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks And Caicos Islands">Turks And Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="US Virgin Islands">US Virgin Islands</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Wallis and Futuna">Wallis and Futuna</option><option value="Western Sahara">Western Sahara</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div> 
                                    </div>
                                </div>
                                <div class="formField textField darkStyle" id="phonecontact">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Phone</span>
                                            <input type="text" value="" name="phonecontact" id="phonecontact" onKeyDown="turnwhite('conphone')">
                                        </label>
                                    </div>
                                </div>
                                <a class="btn btn-small float-right" onClick="showconNextOption()">Next</a>
                                
                            </div>
                            
                        </div>
                        
                        <div class="text-center animateElement" id="contactstep2" style="display:none;" data-animation-type="fadeInUp">
                            <h3 class="text-left">Contact Form</h4>
                            <h4 class="text-left">02. Additional Comments & Submission</h4>
                            <div class="getInTouchForm">
                                <div class="formField textField darkStyle" style="margin-top:30px;">
                                    <div class="formFieldIn">
                                        <label>
                                            <span>Please type your comments</span>
                                            <input type="text" value="" name="contactquery" id="contactquery">
                                        </label>
                                    </div>
                                </div>
                                <div class="checkBoxRadioFieldIn text-left">
                                    <label class="checkBoxContainer" style="text-align:left">
                                        By ticking this box you are consenting to allow NETSOL to contact you from time to time via email about products, services and offers that may be of interest to you.<br><br>
                            <span class="mobileconcent">By submitting your personal details you are consenting to allow NETSOL to process and store your details in line with our privacy policy and to contact you in relation to your submitted enquiry. You can withdraw your marketing consent at any time by sending an email to <a href="mailto:marketing@netsoltech.com" style="text-decoration:underline; color:#1c72b8 !important">marketing@netsoltech.com</a>.
<br><br>
More information on our processing can be found on <a href="privacy-policy" style="text-decoration:underline; color:#1c72b8 !important">PRIVACY POLICY</a></span>
                                        <input type="checkbox" value="Yes" name="acceptcheck2" id="conacceptcheck">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>    
                                <br>
                                <div class="g-recaptcha" data-sitekey="6LdIlIIjAAAAAOVHRtWn018XvqGbFU-J3JC52SjF"></div>
    							<!--<div id="g-recaptcha-error2"></div>-->
                            
                            <input type="submit" class="btn mgntop20 float-left" value="Submit" />
                            </div>
                            
                        </div>
                        <div class="progress_row step_progress_con" id="conprogbar" style="display:;">
                            <div class="progress_block step1con">
                                <div class="progress_number active">01</div>
                                <div class="progress_bar active"></div>
                            </div>
                            <div class="progress_block step2con">
                                <div class="progress_number">02</div>
                                <div class="progress_bar"></div>
                            </div>
                        </div>
                    </form>
                    <div class="text-center pad-bottom-100 animateElement" id="thankyounote2" style="display:none; padding-top:225px;" data-animation-type="fadeInUp">
                        <h4></h4>
                        <h3>Thankyou! <br> You will be contacted shortly.</h3>
                        <br>
                        <a class="btn mgntop20" onClick="contactform()">Submit Another Request</a>
                    </div>
                    
                </div>
                
            </div>
        </div>

        <div class="contactInfo clearfix">
            <div class="contactInfoList animateElement" data-animation-type="fadeInUp" id="globalOffices">
                <h4>Global Offices</h4>
                <p>
                    <a class="active" href="calabasasUS">Encino, USA</a><br>
                    <a href="londonUK">London, UK</a><br>
                    <a href="sydneyAus">Sydney, Australia</a><br>
                    <a href="beijingChina">Beijing, China</a><br>
                    <a href="shanghaiChina">Tianjin, China</a><br>
                    <a href="bankokThailand">Bangkok, Thailand</a><br>
                    <a href="jakartaIndonesia">Jakarta, Indonesia</a><br>
                    <a href="lahorePakistan">Lahore, Pakistan</a>
                </p>
            </div>
            <div class="contactInfoList animateElement" data-animation-type="fadeInUp">
                <h4>Contact Information</h4>
                <div data-id="calabasasUS" class="globalOfficesText" style="display: block;">
                    <p>Corporate Headquarters</p>
                    <p>Phone<br>+1 818 222 9195</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
                <div data-id="londonUK" class="globalOfficesText">
                    <p>NETSOL Technologies Europe Ltd.</p>
                    <p>Phone<br>+44 2 0398 10290</p>
                    <p>Email<br>info-eu@netsoltech.com</p>
                </div>
                <div data-id="sydneyAus" class="globalOfficesText">
                    <p>NETSOL Technologies (Australia)</p>
                    <!-- +61 2 9221 2081 -->
                    <p>Phone <br>+61 2 9221 2081</p>
                    <p>Fax <br>+61 2 9221 1664</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
                <div data-id="beijingChina" class="globalOfficesText">
                    <p>NETSOL Technologies Ltd. (China)</p>
                    <p>Phone <br>+86 10 6568 2256</p>
                    <p>Fax <br>+86 10 6568 0696</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
                <div data-id="shanghaiChina" class="globalOfficesText">
                    <p>NETSOL Technologies Ltd. (China)</p>
                    <p>Phone <br>+86 10 6568 0696</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
                <div data-id="bankokThailand" class="globalOfficesText">
                    <p>NETSOL Technologies (Thailand) Ltd.</p>
                    <p>Phone <br>+66 2685 3552 3</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
                <div data-id="jakartaIndonesia" class="globalOfficesText">
                    <p>NETSOL Technologies Inc. (Indonesia)</p>
                    <p>Phone <br>+62 21 29295074<br>+62 21 29655859</p>
                    <p>Fax <br>+62 21 2655801</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
                
                <div data-id="lahorePakistan" class="globalOfficesText">
                    <p>NETSOL Technologies Ltd. (Pakistan)</p>
                    <p>Phone <br>+92 42 111 44 88 00</p>
                    <p>Email<br>info@netsoltech.com</p>
                </div>
            </div>
            <div class="contactInfoList animateElement" data-animation-type="fadeInUp">
                <h4>Address</h4>
                <div data-id="calabasasUS" class="globalOfficesText" style="display: block;">
                    <p>16000 Ventura Blvd;<br /> Suite 770<br /> Encino, CA 91436, USA</p>
                </div>
                <div data-id="londonUK" class="globalOfficesText">
                    <p>40 Gracechurch Street <br>London <br>EC3V 0BT</p>
                </div>
                <div data-id="sydneyAus" class="globalOfficesText">
                    <p>Level 2, <br>61 York Street, <br>Sydney, <br>NSW, 2000, <br>Australia</p>
                </div>
                <div data-id="beijingChina" class="globalOfficesText">
                    <p>2803, China Overseas Plaza, <br /> No. 8, Guanghua Dongli, <br /> Chaoyang District, <br />Beijing,China.</p>
                </div>
                <div data-id="shanghaiChina" class="globalOfficesText">
                    <p>703, Tianjin Chow Tai Fook Financial Center,<br /> No. 61, First Street,<br /> Tianjin Development Zone,<br /> Tianjin, China.</p>
                </div>
                <div data-id="bankokThailand" class="globalOfficesText">
                    <p>87 M Thai Tower, <br>All Seasons Place, <br>12 FL. Witthayu Rd.,<br> Lumpini, Pathumwan,<br> Bangkok, 10330</p>
                </div>
                <div data-id="jakartaIndonesia" class="globalOfficesText">
                    <p>Sentral Senayan 2, <br>16th Floor (FORTICE OFFICE), <br>Jl. Asia Afrika No. 8. Gelora Bung Karno, <br>Jakarta Pusat 10270, Indonesia</p>
                </div>
                <div data-id="lahorePakistan" class="globalOfficesText">
                    <p>NETSOL Avenue, <br>Main Ghazi Road Lahore, <br>Pakistan</p>
                </div>
            </div>    
        </div>

    </div>
    
    <script>
		
		//$(document).ready(function(){
			
			$('#demorequest').on('submit', function(e){
				//Stop the form from submitting itself to the server.
				
				var response = grecaptcha.getResponse();
				if(response.length == 0) {
					document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red; text-align:left; float:left; width:100%;">This field is required.</span>';
					return false;
				}
				//return true;
				
				e.preventDefault();
				
				var name = $("#name input").val();
				var email = $("#email input").val();
				var designation = $("#designation input").val();
				var companyname = $("#companyname input").val();
				var country = $("#country").val();
				var phone = $("#phone input").val();
				var demo_for = $('input:checkbox:checked.demo_class').map(function(){ return this.value; }).get().join(",");
				var typeofbusiness = $('input:checkbox:checked.business_class').map(function(){ return this.value; }).get().join(",");
				var typeofleases = $('input:checkbox:checked.lease_class').map(function(){ return this.value; }).get().join(",");
				var typesoforg = $('input:checkbox:checked.org_class').map(function(){ return this.value; }).get().join(",");
				var contractvol = $("#contractvol").val();
				var acceptance = $("#acceptance").val();
				var comments = $("#comments").val();
				// Returns successful data submission message when the entered information is stored in database.
				var dataString = 'name=' + name + '&company=' + companyname + '&designation=' + designation + '&email=' + email + '&country=' + country + '&phone=' + phone + '&demo_for=' + demo_for + '&typeofbusiness=' + typeofbusiness + '&typeofleases=' + typeofleases + '&typesoforg=' + typesoforg + '&contract_vol=' + contractvol + '&comments=' + comments + '&acceptcheck=' + acceptance;
					
				$.ajax({
					type: "POST",
					url: "db-queries/demo_request.php",
					data: dataString,
					cache: false,
					success: function(res) {
						//alert("entering");
						if (res == "fail") {
							//alert("fail");
							$('.error2').show();
						}
						else {
							//alert("success");
							//resetform();
							//$('#thankyounote').fadeIn('slow');
							document.getElementsByName('demorequest')[0].reset();
							//window.location.href="thank-you.php";
							return gtag_report_conversion('thank-you.php');
							$('.error2').hide();
							
							//$('#captecha2').addClass('error');
							//$('.caperror').show('error');
						} 
					},
					error: function () {
						alert("There is some network problem, kindly check later!");
					}
					
				});

				return false;
			});
			
			function verifyCaptcha(){
				document.getElementById('g-recaptcha-error').innerHTML = '';
			}
			
			$('#contactrequest').on('submit', function(e){
				//Stop the form from submitting itself to the server.
					
					/*var response = grecaptcha.getResponse();
					if(response.length == 0) {
						document.getElementById('g-recaptcha-error2').innerHTML = '<span style="color:red; text-align:left; float:left; width:100%;">Please validate captcha.</span>';
						return false;
					}*/
					
					e.preventDefault();
					
					var contactname = $("#contactname input").val();
					var contactemail = $("#contactemail input").val();
					var contactdesignation = $("#contactdesignation input").val();
					var contactcompany = $("#contactcompany input").val();
					var contactcountry = $("#contactcountry").val();
					var phonecontact = $("#phonecontact input").val();
					var contactquery = $("#contactquery").val();
					var conacceptcheck = $("#conacceptcheck").val();
					
					// Returns successful data submission message when the entered information is stored in database.
					var dataString2 = 'contactname=' + contactname + '&contactemail=' + contactemail + '&contactdesignation=' + contactdesignation + '&contactcompany=' + contactcompany + '&contactcountry=' + contactcountry + '&phonecontact=' + phonecontact + '&contactquery=' + contactquery + '&acceptcheck2=' + conacceptcheck;
					//alert("Sending Information");
					$.ajax({
							type: "POST",
							url: "db-queries/contact_request.php",
							data: dataString2,
							cache: false,
							success: function(res) {
								if (res == 'done') {
									//alert(res);
									$('#contactstep2').fadeOut('fast');
									//$('#thankyounote2').fadeIn('fast');
									document.getElementsByName('contactrequest')[0].reset();
									//window.location.href="thank-you.php";
									return gtag_report_conversion('thank-you.php');
									refreshCaptcha();
									$('.error').hide();
								}
								else {
									//alert(res);
									$('.error').show();
								} 
							},
							error:function (){
								alert("There is some network problem, kindly check later!");
							}
							
						});
					return false;
			});
			
			
			/*function verifyCaptcha2(){
				document.getElementById('g-recaptcha-error2').innerHTML = '';
			}*/
			
		//});
		
		
		function turnwhite(id){
			if(id == 'name'){
				$('#name').removeClass('error');
			}
			if(id == 'email'){
				$('#email').removeClass('error');
			}
			if(id == 'designation'){
				$('#designation').removeClass('error');
			}
			if(id == 'companyname'){
				$('#companyname').removeClass('error');
			}
			if(id == 'phone'){
				$('#phone').removeClass('error');
			}
			
			if(id == 'conname'){
				$('#contactname').removeClass('error');
			}
			if(id == 'conemail'){
				$('#contactemail').removeClass('error');
			}
			if(id == 'condesignation'){
				$('#contactdesignation').removeClass('error');
			}
			if(id == 'concompany'){
				$('#contactcompany').removeClass('error');
			}
			if(id == 'concountry'){
				$('#contactname').removeClass('error');
			}
			if(id == 'conphone'){
				$('#phonecontact').removeClass('error');
			}
			if(id == 'concapetcha'){
				$('#capetcha').removeClass('error');
			}
		}
	
		function showQuestion(){
			resetform();
			$('#question1').fadeIn('slow');
			$('.step_progress').fadeIn('slow');
			$('.step1 .progress_number').addClass('active');
			$('.step1 .progress_bar').addClass('active');
			
			$('.step2 .progress_number').removeClass('active');
			$('.step2 .progress_bar').removeClass('active');
			$('.step3 .progress_number').removeClass('active');
			$('.step3 .progress_bar').removeClass('active');
			$('.step4 .progress_number').removeClass('active');
			$('.step4 .progress_bar').removeClass('active');
			$('.step5 .progress_number').removeClass('active');
			$('.step5 .progress_bar').removeClass('active');
			$('.step6 .progress_number').removeClass('active');
			$('.step6 .progress_bar').removeClass('active');
			$('.step7 .progress_number').removeClass('active');
			$('.step7 .progress_bar').removeClass('active');
		}
		
		function showconNextOption(){
			var contactname = $("#contactname input").val();
			var contactemail = $("#contactemail input").val();
			var contactdesignation = $("#contactdesignation input").val();
			var contactcompany = $("#contactcompany input").val();
			var phonecontact = $("#phonecontact input").val();
			
			if(contactname == '' || contactname == null){
				$('#contactname').addClass('error');
				//alert("please enter name");	
			}
			if(contactemail == '' || contactemail == null){
				$('#contactemail').addClass('error');
				//alert("please enter email");	
			}
			if(!validateEmail(contactemail)){
				$("#invalidconemail").show();
			}
			if(contactdesignation == '' || contactdesignation == null){
				$('#contactdesignation').addClass('error');
				//alert("please enter designation");	
			}
			if(contactcompany == '' || contactcompany == null){
				$('#contactcompany').addClass('error');
				//alert("please enter company name");	
			}
			if(phonecontact == '' || phonecontact == null){
				$('#phonecontact').addClass('error');
				//alert("please enter phone");	
			}
			
			if(validateEmail(contactemail)){
				$("#invalidconemail").hide();
				if(contactname != '' && contactemail != '' && contactdesignation != '' && contactcompany != '' && phonecontact!= ''){
					$('#contactform').fadeOut('fast');
					$('#contactstep2').fadeIn('slow');
				}
			}
			
			$('.step2con .progress_number').addClass('active');
			$('.step2con .progress_bar').addClass('active');
			$("#conprogbar").hide();
		}
		
		function showNextOption(){
			var name = $("#name input").val();
			var email = $("#email input").val();
			var designation = $("#designation input").val();
			var companyname = $("#companyname input").val();
			var phone = $("#phone input").val();
			if(name == '' || name == null){
				$("#name").addClass('error');
				//alert("please enter name");
			}
			if(email == '' || email == null){
				$("#email").addClass('error');
				//alert("please enter email");	
			}
			if(!validateEmail(email)){
				$(".checkemail").addClass('error');
			    $("#invalidemail").show();
			}
			if(designation == '' || designation == null){
				$("#designation").addClass('error');
				//alert("please enter designation");	
			}
			if(companyname == '' || companyname == null){
				$("#companyname").addClass('error');
				//alert("please enter company name");	
			}
			if(phone == '' || phone == null){
				$("#phone").addClass('error');
				//alert("please enter phone");	
			}
			if(validateEmail(email)){
				if(name != '' && email != '' && designation != '' && companyname != '' && phone != ''){
					resetform();
					$('#question2').fadeIn('slow');	
					
					$('.step_progress').fadeIn('slow');
					$('.step1 .progress_number').addClass('active');
					$('.step1 .progress_bar').addClass('active');
					$('.step2 .progress_number').addClass('active');
					$('.step2 .progress_bar').addClass('active');
					
					$('.step3 .progress_number').removeClass('active');
					$('.step3 .progress_bar').removeClass('active');
					$('.step4 .progress_number').removeClass('active');
					$('.step4 .progress_bar').removeClass('active');
					$('.step5 .progress_number').removeClass('active');
					$('.step5 .progress_bar').removeClass('active');
					$('.step6 .progress_number').removeClass('active');
					$('.step6 .progress_bar').removeClass('active');
					$('.step7 .progress_number').removeClass('active');
					$('.step7 .progress_bar').removeClass('active');
					
				}
			}
			
		}
		
		function validateEmail($email) {
		  var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		  if(!regex.test($email)) {
			   return false;
		  }else{
			   $(".checkemail").removeClass('error');
			   $("#invalidemail").hide();
			   return true;
		  }
		}
		
		function showNextOption2(){
			
			if ($(".demo_class:checked").length > 0){
				resetform();
				$('#question3').fadeIn('slow');
		
				$('.step_progress').fadeIn('slow');
				$('.step1 .progress_number').addClass('active');
				$('.step1 .progress_bar').addClass('active');
				$('.step2 .progress_number').addClass('active');
				$('.step2 .progress_bar').addClass('active');
				$('.step3 .progress_number').addClass('active');
				$('.step3 .progress_bar').addClass('active');
				
				$('.step4 .progress_number').removeClass('active');
				$('.step4 .progress_bar').removeClass('active');
				$('.step5 .progress_number').removeClass('active');
				$('.step5 .progress_bar').removeClass('active');
				$('.step6 .progress_number').removeClass('active');
				$('.step6 .progress_bar').removeClass('active');
				$('.step7 .progress_number').removeClass('active');
				$('.step7 .progress_bar').removeClass('active');
				
				$(".demo_que").removeClass("error");
				$(".step2").removeClass("error");
			}
			else{
				$(".demo_que").addClass("error");
				$(".step2").addClass("error");
			}
			
		}
		
		function showNextOption3(){
			
			if ($(".business_class:checked").length > 0){
				resetform();
				$('#question4').fadeIn('slow');
				
				$('.step_progress').fadeIn('slow');
				$('.step1 .progress_number').addClass('active');
				$('.step1 .progress_bar').addClass('active');
				$('.step2 .progress_number').addClass('active');
				$('.step2 .progress_bar').addClass('active');
				$('.step3 .progress_number').addClass('active');
				$('.step3 .progress_bar').addClass('active');
				$('.step4 .progress_number').addClass('active');
				$('.step4 .progress_bar').addClass('active');
				
				$('.step5 .progress_number').removeClass('active');
				$('.step5 .progress_bar').removeClass('active');
				$('.step6 .progress_number').removeClass('active');
				$('.step6 .progress_bar').removeClass('active');
				$('.step7 .progress_number').removeClass('active');
				$('.step7 .progress_bar').removeClass('active');
				
				$(".business_que").removeClass("error");
				$(".step3").removeClass("error");
			}
			else{
				$(".business_que").addClass("error");
				$(".step3").addClass("error");
			}	
		}
		
		function showNextOption4(){
			resetform();
			$('#question5').fadeIn('slow');	
			
			$('.step_progress').fadeIn('slow');
			$('.step1 .progress_number').addClass('active');
			$('.step1 .progress_bar').addClass('active');
			$('.step2 .progress_number').addClass('active');
			$('.step2 .progress_bar').addClass('active');
			$('.step3 .progress_number').addClass('active');
			$('.step3 .progress_bar').addClass('active');
			$('.step4 .progress_number').addClass('active');
			$('.step4 .progress_bar').addClass('active');
			$('.step5 .progress_number').addClass('active');
			$('.step5 .progress_bar').addClass('active');
			
			$('.step6 .progress_number').removeClass('active');
			$('.step6 .progress_bar').removeClass('active');
			$('.step7 .progress_number').removeClass('active');
			$('.step7 .progress_bar').removeClass('active');
		}
		function showNextOption5(){
			
			if ($(".lease_class:checked").length > 0){
				resetform();
				$('#question6').fadeIn('slow');
				
				$('.step_progress').fadeIn('slow');
				$('.step1 .progress_number').addClass('active');
				$('.step1 .progress_bar').addClass('active');
				$('.step2 .progress_number').addClass('active');
				$('.step2 .progress_bar').addClass('active');
				$('.step3 .progress_number').addClass('active');
				$('.step3 .progress_bar').addClass('active');
				$('.step4 .progress_number').addClass('active');
				$('.step4 .progress_bar').addClass('active');
				$('.step5 .progress_number').addClass('active');
				$('.step5 .progress_bar').addClass('active');
				$('.step6 .progress_number').addClass('active');
				$('.step6 .progress_bar').addClass('active');
				
				$('.step7 .progress_number').removeClass('active');
				$('.step7 .progress_bar').removeClass('active');
				
				$(".lease_que").removeClass("error");
				$(".step5").removeClass("error");
			}
			else{
				$(".lease_que").addClass("error");
				$(".step5").addClass("error");
			}	
		}
		
		function showNextOption6(){
			
			if ($(".org_class:checked").length > 0){
				resetform();
				$('#question7').fadeIn('slow');	
				
				$('.step_progress').fadeIn('slow');
				$('.step1 .progress_number').addClass('active');
				$('.step1 .progress_bar').addClass('active');
				$('.step2 .progress_number').addClass('active');
				$('.step2 .progress_bar').addClass('active');
				$('.step3 .progress_number').addClass('active');
				$('.step3 .progress_bar').addClass('active');
				$('.step4 .progress_number').addClass('active');
				$('.step4 .progress_bar').addClass('active');
				$('.step5 .progress_number').addClass('active');
				$('.step5 .progress_bar').addClass('active');
				$('.step6 .progress_number').addClass('active');
				$('.step6 .progress_bar').addClass('active');
				$('.step7 .progress_number').addClass('active');
				$('.step7 .progress_bar').addClass('active');
				
				$(".org_que").removeClass("error");
				$(".step6").removeClass("error");
				
				$("#demoprogbar").hide();
			}
			else{
				$(".org_que").addClass("error");
				$(".step6").addClass("error");
				$("#demoprogbar").hide();
			}
		}
		function showNextOption7(){
			resetform();
			$('#question8').fadeIn('slow');	
		}
		/*function showNextOption8(){
			//alert("here");
			resetform();
			$.ajax({
				url:'db-queries/demo_request.php',
				type:'POST',
				data:$('#demorequest').serialize(),
				success:function(){
					//alert("worked");
					$('#thankyounote').fadeIn('slow');
				}	
			});
			
		}*/
		
		function showstart(){
			resetform();
			$('#start').fadeIn('fast');
			$('#contactform2').fadeIn('fast');
		}
		
		function resetform(){
			$('#question1').fadeOut('fast');
			$('#question2').fadeOut('fast');
			$('#question3').fadeOut('fast');
			$('#question4').fadeOut('fast');
			$('#question5').fadeOut('fast');
			$('#question6').fadeOut('fast');
			$('#question7').fadeOut('fast');
			$('#question8').fadeOut('fast');
			$('#start').fadeOut('fast');
			$('#thankyounote').fadeOut('fast');
			//$('#contactform').fadeOut('fast');
			//$('#contactform2').fadeOut('fast');
		}
		
		function contactform(){
			$('#contactform').fadeIn('slow');
			/*$('#question1').fadeOut('fast');
			$('#question2').fadeOut('fast');
			$('#question3').fadeOut('fast');
			$('#question4').fadeOut('fast');
			$('#question5').fadeOut('fast');
			$('#question6').fadeOut('fast');
			$('#question7').fadeOut('fast');
			$('#question8').fadeOut('fast');*/
			$('#start-contact').fadeOut('fast');
			$('#thankyounote2').fadeOut('fast');
			$('.step_progress_con').fadeIn('slow');
			$('.step1con .progress_number').addClass('active');
			$('.step1con .progress_bar').addClass('active');
		}
		
		
		$('input[name="otherbiz"]').change(function(){
			if (this.checked) {
				$('#otherbizfield').fadeIn('slow');
				//alert("Thanks for checking me");
			}
			else{
				$('#otherbizfield').fadeOut('fast');
			}
		});
		
		$('input[name="otherlease"]').change(function(){
			if (this.checked) {
				$('#otherleasefield').fadeIn('slow');
				//alert("Thanks for checking me");
			}
			else{
				$('#otherleasefield').fadeOut('fast');
			}
		});
		
		$('input[name="otherorg"]').change(function(){
			if (this.checked) {
				$('#otherorgfield').fadeIn('slow');
				//alert("Thanks for checking me");
			}
			else{
				$('#otherorgfield').fadeOut('fast');
			}
		});
		
	</script>
    
<footer id="footer">
     <div class="container">
        <div class="footerContents clearfix">
            <div class="footerCol">
                <h4>CONTACT US</h4>
                <p> 
                    Corporate Headquarters<br> 16000 Ventura Blvd;<br>Suite 770<br>Encino, CA 91436,<br>USA<br><a href="tel:+1 818 222 9195">+1 818 222 9195</a><br><a href="mailto:info@netsoltech.com">info@netsoltech.com</a>
                </p>
            </div>
            <div class="footerCol">
                <h4>COMPANY</h4>
                <ul>
                    <li><a href="about-us">About Us</a></li>
                    <li><a href="about-us#boardOfDirector">Board of Directors</a></li>
                    <li><a href="about-us#managementTeam">Management Team</a></li>
                    <li><a href="about-us-sr">Social Responsibilities</a></li>
                    <!-- <li><a href="http://careers.netsolpk.com" target="_blank">Careers</a></li> -->
                </ul>
            </div>
            <div class="footerCol">
                <h4>NFS ASCENT<sup>&reg;</sup> </h4>
                <ul>
                    <li><a href="front-office-enablement">Front Office</a></li>
                    <li><a href="back-office-enablement">Back Office</a></li>
                    <li><a href="customer-self-service">Self Service</a></li>
                </ul>
            </div>
            <div class="footerCol">
                <h4>NFS DIGITAL</h4>
                <ul>
                    <li><a href="digital-self-service-enablement">Self Point of Sale</a></li>
                    <li><a href="digital-self-service-enablement#mAccount">Mobile Account</a></li>
                    <li><a href="digital-dealership-enablement">Mobile Point of Sale</a></li>
                    <li><a href="digital-dealership-enablement#webPos">Web Point of Sale</a></li>
                    <li><a href="digital-field-team-enablement">Mobile Field Investigator</a></li>
                    <li><a href="digital-field-team-enablement#mcollector">Mobile Collector</a></li>
                    <li><a href="digital-floorplan-enablement">Mobile Dealer</a></li>
                    <li><a href="digital-floorplan-enablement#mAuditor">Mobile Auditor</a></li>
                    
                </ul>
            </div>
        </div>
        <div class="footerContents clearfix">
            <div class="footerCol">
                <h4>OFFICES</h4>
                <p>
                    <label>Encino</label> <a href="tel:+1 818 222 9195">+1 818 222 9195</a><br />
                    <label>London</label> <a href="tel:+44 0 1403 282300">+44 2 0398 10290</a><br />
                    <!-- +61 2 9221 2081 -->
                    <label>Sydney</label> <a href="tel:+61 2 9159 0165">+61 2 9159 0165</a><br />
                    <label>Beijing</label> <a href="tel:+86 10 6568 2256">+86 10 6568 2256</a><br />
                    <label>Shanghai</label> <a href="tel:+86 21 6020 6700">+86 21 6020 6700</a><br />
                    <label>Bangkok</label> <a href="tel:+66 2685 3552 3">+66 2685 3552 3</a><br />
                    <label>Jakarta</label> <a href="tel:+62 21 2965 5859">+62 21 2965 5859</a><br />
                    <label>Lahore</label> <a href="tel:+92 42 111 44 88 00">+92 42 111 44 88 00</a>
                </p>  
            </div>
            <div class="footerCol">
                <h4>INVESTORS</h4>
                <ul>
                    <li><a href="https://ir.netsoltech.com/">Overview</a></li>
                    <li><a href="https://ir.netsoltech.com/company-information">Company Information</a></li>
                    <li><a href="https://ir.netsoltech.com/press-releases">News</a></li>
                    <li><a href="https://ir.netsoltech.com/stock-data">Stock Data</a></li>
                    <li><a href="https://ir.netsoltech.com/all-sec-filings">SEC Filings</a></li>
                </ul>
            </div>
            <div class="footerCol">
                <h4>Innovation</h4>
                <ul>
                    <li><a href="innovation">Overview</a></li>
                    <li><a href="articles">Articles</a></li>
                    <li><a href="downloads">Downloads</a></li>
                    <li><a href="in-the-lab">In the Lab</a></li>
                </ul>
            </div>
            <div class="footerCol">
                <h4>FOLLOW</h4>
                <ul>
                    <li><a href="https://twitter.com/netsoltech" target="_blank">Twitter <img src="images/twitter-icon.svg" alt="#" /></a></li>
                    <li><a href="https://linkedin.com/company/netsol-technologies-inc-" target="_blank">LinkedIn <img src="images/linkedin-icon.svg" alt="#" /></a></li>
                </ul>  
            </div>
        </div>
        <div id="copyRights">
            <p class="float-left">&copy; 2023 NETSOL Technologies. All Rights Reserved.</p><p class="float-right"><a href="terms-of-use">Terms of Use</a> | <a href="privacy-policy">Privacy Policy</a> | <a href="about-us-sr">Human Rights Policy</a> | <a href="about-us-sr#ModernSlaveryAct">Modern Slavery Act</a></p>
        </div>
    </div>
</footer> 


<div id="mainRequestDemo" class="model-window globaldemo">
    <div class="model-overlay"></div>
    <div class="model-content modal-large wizard-model bgSection" style="overflow:hidden; background:#fff !important;">
        <a class="close-window"></a>
        
        <!--<div class="text-center clearfix pad-bottom-100 mgntop-vh-15" id="start-footer" style="margin-top:25vh">
            <div class="width100">
                <h3 class="mgntop30 animateElement" data-animation-type="fadeInUp" style="color:#fff;">Request Demo Form</h3>
                <a class="btn btn-white mgntop60 animateElement" data-animation-type="fadeInUp" onClick="showQuestionfooter()">Start</a>
            </div>
            
        </div>-->
        
        <form method="post" name="demorequest-footer" id="demorequest-footer">
                
                <div class="text-center padtop0 mgntop20 animateElement" id="question1-footer" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">01.Enter your basic information</h4>
                    <div class="getInTouchForm mgntop20">
                        <div class="formField textField darkStyle" id="name-footer">
                            <div class="formFieldIn">
                                <label>
                                    <span>Name</span>
                                    <input type="text" value="" name="name" onKeyDown="turnwhitefooter('name');">
                                </label>
                            </div>
                        </div>
                        <div class="formField textField darkStyle" id="email-footer">
                            <div class="formFieldIn">
                                <label>
                                    <span>Email</span>
                                    <input type="text" value="" name="email" onKeyDown="turnwhitefooter('email');">
                                </label>
                            </div>
                        </div>
                        <div class="formField textField darkStyle" id="designation-footer">
                            <div class="formFieldIn">
                                <label>
                                    <span>Designation</span>
                                    <input type="text" value="" name="designation" onKeyDown="turnwhitefooter('designation');">
                                </label>
                            </div>
                        </div>
                        <div class="formField textField darkStyle" id="companyname-footer">
                            <div class="formFieldIn">
                                <label>
                                    <span>Company Name</span>
                                    <input type="text" value="" name="companyname" onKeyDown="turnwhitefooter('companyname');">
                                </label>
                            </div>
                        </div>
                        <div class="formField darkStyle">
                            <div class="formFieldIn">
                                <div class="selectField">
                                    <span style="color:#1c72b8">Country</span>
                                    <select name="country" id="country-footer" aria-required="true" aria-invalid="false">
                                    	<option value="United Kingdom" selected>United Kingdom</option><option value="Afghanistan">Afghanistan</option><option value="Aland Islands">Aland Islands</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American Samoa">American Samoa</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antarctica">Antarctica</option><option value="Antigua and Barbuda">Antigua and Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Aruba">Aruba</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option><option value="Botswana">Botswana</option><option value="Bouvet Island">Bouvet Island</option><option value="Brazil">Brazil</option><option value="British Indian Ocean Territory">British Indian Ocean Territory</option><option value="British Virgin Islands">British Virgin Islands</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Christmas Island">Christmas Island</option><option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Democratic Republic of Congo">Democratic Republic of Congo</option><option value="Denmark">Denmark</option><option value="Disputed Territory Djibouti">Disputed Territory Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Falkland Islands">Falkland Islands</option><option value="Faroe Islands">Faroe Islands</option><option value="Federated States of Micronesia">Federated States of Micronesia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guyana">French Guyana</option><option value="French Polynesia">French Polynesia</option><option value="French Southern Territories">French Southern Territories</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Iraq-Saudi Arabia Neutral Zone">Iraq-Saudi Arabia Neutral Zone</option><option value="Ireland">Ireland</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macau">Macau</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia Maldives">Malaysia Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="Netherlands">Netherlands</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Niue">Niue</option><option value="Norfolk Island">Norfolk Island</option><option value="North Korea">North Korea</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Palestinian Territories">Palestinian Territories</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Pitcairn Islands">Pitcairn Islands</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="Saint Helena and Dependencies">Saint Helena and Dependencies</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Georgia and South Sandwich Islands">South Georgia and South Sandwich Islands</option><option value="South Korea">South Korea</option><option value="Spain">Spain</option><option value="Spratly Islands">Spratly Islands</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tokelau">Tokelau</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks And Caicos Islands">Turks And Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="US Virgin Islands">US Virgin Islands</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Wallis and Futuna">Wallis and Futuna</option><option value="Western Sahara">Western Sahara</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option>
                                    </select>
                                </div> 
                    		</div>
                		</div>
                        <div class="formField textField darkStyle" id="phone-footer">
                            <div class="formFieldIn">
                                <label>
                                    <span>Phone</span>
                                    <input type="text" value="" name="phone" onKeyDown="turnwhitefooter('phone');">
                                </label>
                            </div>
                        </div>
                        <a class="btn btn-small float-left" onClick="showstartfooter()">Previous</a>
                    	<a class="btn btn-small float-right" onClick="showNextOptionfooter()">Next</a>
                     </div> 
                </div>
                
                <div class="text-center pad-bottom-100 animateElement" id="question2-footer" style="display:none" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">02. What would you like to request demo for?</h4>
                    <br><br>
                    
                    <div class="checkBoxRadioFieldIn text-left">
                    	                        <label class="checkBoxContainer">
                            Lease Soft
                            <input type="checkbox" value="Lease Soft" name="demo_for[]" id="nfsascent-footer"  class="demo_class" checked="checked">
                            <span class="checkmark"></span>
                        </label>
                                                <label class="checkBoxContainer">
                            NFS Ascent<sup>&reg;</sup> 
                            <input type="checkbox" value="NFS Ascent" name="demo_for[]" id="nfsascent-footer"  class="demo_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            NFS Ascent<sup>&reg;</sup>  On Cloud
                            <input type="checkbox" value="NFS Ascent on Cloud" name="demo_for[]" id="nfsascentcloud-footer"  class="demo_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            NFS Digital
                            <input type="checkbox" value="NFS Digital" name="demo_for[]" id="nfsdigital-footer" class="demo_class">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <br>
                	<a class="btn btn-small float-left" onClick="showQuestionfooter()">Previous</a>
                    <a class="btn btn-small float-right" onClick="showNextOption2footer()">Next</a>
                </div>
                
                <div class="text-center pad-bottom-100 animateElement" id="question3-footer" style="display:none" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">03. What is your type of business?</h4>
                    <br><br>
                    <div class="checkBoxRadioFieldIn text-left">
                        <label class="checkBoxContainer">
                            Retail
                            <input type="checkbox" value="Retail" name="typeofbusiness[]" id="retail-footer"  class="business_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Wholesale
                            <input type="checkbox" value="Wholesale" name="typeofbusiness[]" id="wholesale-footer"  class="business_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Other
                            <input type="checkbox" value="Otherbiz" id="otherbiz-footer" name="otherbiz">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <br>
                    <div class="getInTouchForm mgntop30" style="display:none" id="otherbizfield">
                        <div class="formField textField darkStyle">
                            <div class="formFieldIn" id="nullname-footer">
                                <label>
                                    <span class="nullname">Type of business</span>
                                    <input type="text" value="" name="otob" id="otob-footer">
                                </label>
                            </div>
                        </div>
                    </div>
                    <br>
                	<a class="btn btn-small float-left" onClick="showNextOptionfooter()">Previous</a>
                    <a class="btn btn-small float-right" onClick="showNextOption3footer()">Next</a>
                </div>
                
                <div class="text-center pad-bottom-100 animateElement" id="question4-footer" style="display:none" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">04. What is your annual contract volume?</h4>
                    <br><br>
                    <div class="checkBoxRadioFieldIn text-left">
                        <label class="radioContainer">
                            Less than 10,000
                            <input type="radio" value="Less than 10,000" name="contract_vol[]" id="contractvol-footer" checked>
                            <span class="checkmark"></span>
                        </label>
                        <label class="radioContainer">
                            10,000 - 40,000
                            <input type="radio" value="10,000 - 40,000" name="contract_vol[]" id="contractvol-footer">
                            <span class="checkmark"></span>
                        </label>
                        <label class="radioContainer">
                            40,000 - 70,000
                            <input type="radio" value="40,000 - 70,000" name="contract_vol[]" id="contractvol-footer">
                            <span class="checkmark"></span>
                        </label>
                        <label class="radioContainer">
                            70,000 - 100,000
                            <input type="radio" value="70,000 - 100,000" name="contract_vol[]" id="contractvol-footer">
                            <span class="checkmark"></span>
                        </label>
                        <label class="radioContainer">
                            Greater than 100,000
                            <input type="radio" value="Greater than 100,000" name="contract_vol[]" id="contractvol-footer">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <br>
                	<a class="btn btn-small float-left" onClick="showNextOption2footer()">Previous</a>
                    <a class="btn btn-small float-right" onClick="showNextOption4footer()">Next</a>
                </div>
                
                <div class="text-center pad-bottom-100 animateElement" id="question5-footer" style="display:none" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">05. What type of leases does your company provide?</h4>
                    <br><br>
                    <div class="checkBoxRadioFieldIn text-left">
                        <label class="checkBoxContainer">
                            Financial Lease
                            <input type="checkbox" value="Financial Lease" name="typeofleases[]" id="fl-footer"  class="lease_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Operating Lease
                            <input type="checkbox" value="Operating Lease" name="typeofleases[]" id="ol-footer"  class="lease_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Hire Purchase
                            <input type="checkbox" value="Hire Purchase" name="typeofleases[]" id="hp-footer"  class="lease_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Other
                            <input type="checkbox" value="Other" name="otherlease" id="otherlease-footer">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <br>
                    <div class="getInTouchForm mgntop30" style="display:none" id="otherleasefield-footer">
                        <div class="formField textField darkStyle">
                            <div class="formFieldIn" id="nullname-footer">
                                <label>
                                    <span class="nullname">Type of leases</span>
                                    <input type="text" value="" name="otherleasetype" id="otherleasetype-footer">
                                </label>
                            </div>
                        </div>
                    </div>
                    <br>
                	<a class="btn btn-small float-left" onClick="showNextOption3footer()">Previous</a>
                    <a class="btn btn-small float-right" onClick="showNextOption5footer()">Next</a>
                </div>
                
                <div class="text-center pad-bottom-100 animateElement" id="question6-footer" style="display:none" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">06. Which industry does your organization operate in?</h4>
                    <br><br>
                    <div class="checkBoxRadioFieldIn text-left">
                        <label class="checkBoxContainer">
                            Auto Finance
                            <input type="checkbox" value="Auto Finance" name="typesoforg[]" id="af-footer"  class="org_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Equipment Finance
                            <input type="checkbox" value="Equipment Finance" name="typesoforg[]" id="ef-footer"  class="org_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Big Ticket
                            <input type="checkbox" value="Big Ticket" name="typesoforg[]" id="bg-footer"  class="org_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Bank or subsidiary
                            <input type="checkbox" value="Bank or subsidiary" name="typesoforg[]" id="bs-footer"  class="org_class">
                            <span class="checkmark"></span>
                        </label>
                        <label class="checkBoxContainer">
                            Other
                            <input type="checkbox" value="Other" name="otherorg-footer">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <br>
                    <div class="getInTouchForm mgntop30" style="display:none; float:left; width:100%;" id="otherorgfield-footer">
                        <div class="formField darkStyle">
                            <div class="formFieldIn" id="nullname-footer">
                                <label>
                                    <span class="nullname">Organization Type</span>
                                    <input type="text" value="" name="otherorgtype" id="otherorgtype-footer">
                                </label>
                            </div>
                        </div>
                    </div>
                    <br>
                	<a class="btn btn-small float-left" onClick="showNextOption4footer()">Previous</a>
                    <a class="btn btn-small float-right" onClick="showNextOption6footer()">Next</a>
                </div>
                
                <div class="text-center pad-bottom-100 animateElement" id="question7-footer" style="display:none" data-animation-type="fadeInUp">
                	<h3 class="text-left">Request Demo</h4>
                    <h4 class="text-left">07. Additional Comments & Submission</h4>
                    <br>
                    <h3></h3>
                    <div class="getInTouchForm mgntop30" style="width:100%;">
                        <div class="formField textField darkStyle">
                            <div class="formFieldIn">
                                <label>
                                    <span>Please type any additional comments</span>
                                    <input type="text" value="" name="comments-footer" id="comments-footer">
                                </label>
                            </div>
                        </div>
                        <div class="checkBoxRadioFieldIn">
                            <label class="checkBoxContainer" style="text-align:left">
                                By ticking this box you are consenting to allow NETSOL to contact you from time to time via email about products, services and offers that may be of interest to you.<br><br>
                            <span class="mobileconcent">By submitting your personal details you are consenting to allow NETSOL to process and store your details in line with our privacy policy and to contact you in relation to your submitted enquiry. You can withdraw your marketing consent at any time by sending an email to <a href="mailto:marketing@netsoltech.com" style="text-decoration:underline; color:#1c72b8 !important">marketing@netsoltech.com</a>.
<br><br>
More information on our processing can be found on <a href="privacy-policy" style="text-decoration:underline; color:#1c72b8 !important">PRIVACY POLICY</a></span>
                                <input type="checkbox" value="Yes" name="acceptcheck-footer" id="acceptance-footer">
                                <span class="checkmark"></span>
                            </label>
                        </div>    
                        <br><br>
                        <div class="g-recaptcha" data-sitekey="6LcrqrgUAAAAAKnOOB68FvCIq0nX05jaN43xSx0X" data-callback="verifyCaptcha"></div>
                    <!--<a class="btn btn-white mgntop20" onClick="showNextOption8()">Submit</a>-->
                    <input type="submit" value="Submit" class="btn mgntop20 float-left" />
                    </div>
                </div>
                
                </form>
        <div class="text-center pad-bottom-100 padtop150 animateElement" id="thankyounote-footer" style="display:none; margin-top:9vh" data-animation-type="fadeInUp">
            <h4></h4>
            <h3 style="color:#fff;">Thank you! <br> You will be contacted shortly.</h3>
            <br>
            <a class="btn btn-white mgntop20" onClick="showstartfooter()">Submit Another Request</a>
        </div>
        
        <div class="progress_row step_progress">
            <div class="progress_block step1_footer" style="width:12%">
                <div class="progress_number active">01</div>
                <div class="progress_bar active"></div>
            </div>
            <div class="progress_block step2_footer" style="width:12%">
                <div class="progress_number">02</div>
                <div class="progress_bar"></div>
            </div>
            <div class="progress_block step3_footer" style="width:12%">
                <div class="progress_number">03</div>
                <div class="progress_bar"></div>
            </div>
            <div class="progress_block step4_footer" style="width:12%">
                <div class="progress_number">04</div>
                <div class="progress_bar"></div>
            </div>
            <div class="progress_block step5_footer" style="width:12%">
                <div class="progress_number">05</div>
                <div class="progress_bar"></div>
            </div>
            <div class="progress_block step6_footer" style="width:12%">
                <div class="progress_number">06</div>
                <div class="progress_bar"></div>
            </div>
            <div class="progress_block step7_footer" style="width:12%">
                <div class="progress_number">07</div>
                <div class="progress_bar"></div>
            </div>
        </div>
        
    </div>
</div>


<div id="downloadProfile" class="model-window downloadPopUp">
    <div class="model-overlay"></div>
    <div class="model-content modal-medium text-left">
        <a class="close-window"></a>     
        <h2>Download</h2>    
        <p>To download this file, please fill in the form below.</p>
        <br>
        <form method="post" action="db-queries/downloadfile.php" name="downloadprofile">
        <div class="formField textField darkStyle">
            <div class="formFieldIn">
                <label>
                    <span>Full Name</span>
                    <input type="text" value="" name="name" required id="downloadname">
                </label>
            </div>
        </div>
        <div class="formField textField darkStyle">
            <div class="formFieldIn">
                <label>
                    <span>Email</span>
                    <input type="text" value="" name="email" required id="downloademail">
                </label>
            </div>
        </div>
        <div class="formField textField darkStyle">
            <div class="formFieldIn">
                <label>
                    <span>Company</span>
                    <input type="text" value="" name="company" required id="downloadcompany">
                </label>
            </div>
        </div>
        <div class="termsCheck">
            <label class="checkBoxContainer darkStyle">
                By ticking this box, you are consenting to allow NETSOL to contact you from time to time via email about products, services and offers that may be of interest to you.<br><br>
                    By submitting your personal details, you are consenting to allow NETSOL to process and store your details in line with our privacy policy and to contact you in relation to your submitted enquiry.
                <input type="checkbox">
                <span class="checkmark"></span>
            </label>
        </div>
        <input type="hidden" value="NETSOL Corporate Profile.pdf" name="filename" />
        <br>
        <img id="captcha_code4" src="includes/bot_captcha_code.php" class="flt-lft" width="90" />
        <div class="btnRefresh flt-lft" onClick="refreshCaptcha4();" style="cursor:pointer;"><img src="images/refresh.png" style="float:left; margin-left:10px; margin-top:5px;" width="24" /></div>
        <br><br><br>
        <div class="formField textField darkStyle">
            <div class="formFieldIn">
                <label>
                    <span>Enter above captcha code</span>
                    <input type="text" value="" name="imgLessAttemptdown" id="imgLessAttempt4" autocomplete="false">
                </label>
                <p class='error4 flt-lft' style="display:none; color:#ff0000;">Enter Correct Captcha Code.</p>
            </div>
        </div>
        <input type="submit" value="Download" class="btn btn-small" onclick="downloadFile()" />
        </form>
        
    </div>
</div>

 

</div>

<link href="css/animate.css" rel="stylesheet" type="text/css" />
<script src="js/animationScript.js" type="text/javascript" defer></script>
<script src="js/customScripts.js" type="text/javascript" defer="defer"></script>
<script src="js/canvasScript.js" type="text/javascript" defer="defer"></script>

<!-- <script type="text/javascript">_satellite.pageBottom();</script> -->

<script type="text/javascript">
    function downloadFile(){
	var downloadname = document.getElementById('downloadname').value;
	var downloademail = document.getElementById('downloademail').value;
	var downloadcompany = document.getElementById('downloadcompany').value;
	if(downloadname != '' && downloademail != '' && downloadcompany != ''){
		$('.close-window').click();
	}
}

// Footer Demo Request Form


function turnwhitefooter(id){
	if(id == 'name'){
		$('#name-footer').removeClass('error');
	}
	if(id == 'email'){
		$('#email-footer').removeClass('error');
	}
	if(id == 'designation'){
		$('#designation-footer').removeClass('error');
	}
	if(id == 'companyname'){
		$('#companyname-footer').removeClass('error');
	}
	if(id == 'phone-footer'){
		$('#phone').removeClass('error');
	}
}

function showQuestionfooter(){
	resetformfooter();
	$('.step1_footer .progress_number').addClass('active');
	$('.step1_footer .progress_bar').addClass('active');
	
	$('.step2_footer .progress_number').removeClass('active');
	$('.step2_footer .progress_bar').removeClass('active');
	$('.step3_footer .progress_number').removeClass('active');
	$('.step3_footer .progress_bar').removeClass('active');
	$('.step4_footer .progress_number').removeClass('active');
	$('.step4_footer .progress_bar').removeClass('active');
	$('.step5_footer .progress_number').removeClass('active');
	$('.step5_footer .progress_bar').removeClass('active');
	$('.step6_footer .progress_number').removeClass('active');
	$('.step6_footer .progress_bar').removeClass('active');
	$('.step7_footer .progress_number').removeClass('active');
	$('.step7_footer .progress_bar').removeClass('active');
	$('#question1-footer').fadeIn('slow');
}

function showNextOptionfooter(){
	var name = $("#name-footer input").val();
	var email = $("#email-footer input").val();
	var designation = $("#designation-footer input").val();
	var companyname = $("#companyname-footer input").val();
	var phone = $("#phone-footer input").val();
	if(name == '' || name == null){
		$("#name-footer").addClass('error');
		//alert("please enter name");
	}
	if(email == '' || email == null){
		$("#email-footer").addClass('error');
		//alert("please enter email");	
	}
	if(!ValidateEmail(email)){
		$("#email-footer").addClass('error');
	}
	if(designation == '' || designation == null){
		$("#designation-footer").addClass('error');
		//alert("please enter designation");	
	}
	if(companyname == '' || companyname == null){
		$("#companyname-footer").addClass('error');
		//alert("please enter company name");	
	}
	if(phone == '' || phone == null){
		$("#phone-footer").addClass('error');
		//alert("please enter phone");	
	}
	if(name != '' && email != '' && designation != '' && companyname != '' && phone != ''){
		$('.step1_footer .progress_number').addClass('active');
		$('.step1_footer .progress_bar').addClass('active');
		$('.step2_footer .progress_number').addClass('active');
		$('.step2_footer .progress_bar').addClass('active');
		
		$('.step3_footer .progress_number').removeClass('active');
		$('.step3_footer .progress_bar').removeClass('active');
		$('.step4_footer .progress_number').removeClass('active');
		$('.step4_footer .progress_bar').removeClass('active');
		$('.step5_footer .progress_number').removeClass('active');
		$('.step5_footer .progress_bar').removeClass('active');
		$('.step6_footer .progress_number').removeClass('active');
		$('.step6_footer .progress_bar').removeClass('active');
		$('.step7_footer .progress_number').removeClass('active');
		$('.step7_footer .progress_bar').removeClass('active');
		$('#question1-footer').fadeOut('fast');
		$('#question2-footer').fadeIn('slow');	
	}
}

function ValidateEmail(email) {	
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

function showNextOption2footer(){
	resetformfooter();
	$('#question3-footer').fadeIn('slow');
	$('.step1_footer .progress_number').addClass('active');
	$('.step1_footer .progress_bar').addClass('active');
	$('.step2_footer .progress_number').addClass('active');
	$('.step2_footer .progress_bar').addClass('active');
	$('.step3_footer .progress_number').addClass('active');
	$('.step3_footer .progress_bar').addClass('active');
	
	$('.step4_footer .progress_number').removeClass('active');
	$('.step4_footer .progress_bar').removeClass('active');
	$('.step5_footer .progress_number').removeClass('active');
	$('.step5_footer .progress_bar').removeClass('active');
	$('.step6_footer .progress_number').removeClass('active');
	$('.step6_footer .progress_bar').removeClass('active');
	$('.step7_footer .progress_number').removeClass('active');
	$('.step7_footer .progress_bar').removeClass('active');	
}
function showNextOption3footer(){
	resetformfooter();
	$('#question4-footer').fadeIn('slow');
	$('.step1_footer .progress_number').addClass('active');
	$('.step1_footer .progress_bar').addClass('active');
	$('.step2_footer .progress_number').addClass('active');
	$('.step2_footer .progress_bar').addClass('active');
	$('.step3_footer .progress_number').addClass('active');
	$('.step3_footer .progress_bar').addClass('active');
	$('.step4_footer .progress_number').addClass('active');
	$('.step4_footer .progress_bar').addClass('active');
	
	$('.step5_footer .progress_number').removeClass('active');
	$('.step5_footer .progress_bar').removeClass('active');
	$('.step6_footer .progress_number').removeClass('active');
	$('.step6_footer .progress_bar').removeClass('active');
	$('.step7_footer .progress_number').removeClass('active');
	$('.step7_footer .progress_bar').removeClass('active');
}
function showNextOption4footer(){
	resetformfooter();
	$('.step1_footer .progress_number').addClass('active');
	$('.step1_footer .progress_bar').addClass('active');
	$('.step2_footer .progress_number').addClass('active');
	$('.step2_footer .progress_bar').addClass('active');
	$('.step3_footer .progress_number').addClass('active');
	$('.step3_footer .progress_bar').addClass('active');
	$('.step4_footer .progress_number').addClass('active');
	$('.step4_footer .progress_bar').addClass('active');
	$('.step5_footer .progress_number').addClass('active');
	$('.step5_footer .progress_bar').addClass('active');
	
	$('.step6_footer .progress_number').removeClass('active');
	$('.step6_footer .progress_bar').removeClass('active');
	$('.step7_footer .progress_number').removeClass('active');
	$('.step7_footer .progress_bar').removeClass('active');
	$('#question5-footer').fadeIn('slow');	
}
function showNextOption5footer(){
	resetformfooter();
	$('.step1_footer .progress_number').addClass('active');
	$('.step1_footer .progress_bar').addClass('active');
	$('.step2_footer .progress_number').addClass('active');
	$('.step2_footer .progress_bar').addClass('active');
	$('.step3_footer .progress_number').addClass('active');
	$('.step3_footer .progress_bar').addClass('active');
	$('.step4_footer .progress_number').addClass('active');
	$('.step4_footer .progress_bar').addClass('active');
	$('.step5_footer .progress_number').addClass('active');
	$('.step5_footer .progress_bar').addClass('active');
	$('.step6_footer .progress_number').addClass('active');
	$('.step6_footer .progress_bar').addClass('active');
	
	$('.step7_footer .progress_number').removeClass('active');
	$('.step7_footer .progress_bar').removeClass('active');
	$('#question6-footer').fadeIn('slow');	
}
function showNextOption6footer(){
	resetformfooter();
	$('.step1_footer .progress_number').addClass('active');
	$('.step1_footer .progress_bar').addClass('active');
	$('.step2_footer .progress_number').addClass('active');
	$('.step2_footer .progress_bar').addClass('active');
	$('.step3_footer .progress_number').addClass('active');
	$('.step3_footer .progress_bar').addClass('active');
	$('.step4_footer .progress_number').addClass('active');
	$('.step4_footer .progress_bar').addClass('active');
	$('.step5_footer .progress_number').addClass('active');
	$('.step5_footer .progress_bar').addClass('active');
	$('.step6_footer .progress_number').addClass('active');
	$('.step6_footer .progress_bar').addClass('active');
	$('.step7_footer .progress_number').addClass('active');
	$('.step7_footer .progress_bar').addClass('active');
	$('#question7-footer').fadeIn('slow');	
}
function showNextOption7footer(){
	resetformfooter();
	$('#question8-footer').fadeIn('slow');	
}

function showstartfooter(){
	resetformfooter();
	$('#question1-footer').fadeIn('fast');
	//$('#`').fadeIn('fast');
}

function resetformfooter(){
	$('#question1-footer').fadeOut('fast');
	$('#question2-footer').fadeOut('fast');
	$('#question3-footer').fadeOut('fast');
	$('#question4-footer').fadeOut('fast');
	$('#question5-footer').fadeOut('fast');
	$('#question6-footer').fadeOut('fast');
	$('#question7-footer').fadeOut('fast');
	$('#question8-footer').fadeOut('fast');
	$('#start-footer').fadeOut('fast');
	$('#thankyounote-footer').fadeOut('fast');
}

$('input[name="otherbiz-footer"]').change(function(){
	if (this.checked) {
		$('#otherbizfield-footer').fadeIn('slow');
		//alert("Thanks for checking me");
	}
	else{
		$('#otherbizfield-footer').fadeOut('fast');
	}
});

$('input[name="otherlease-footer"]').change(function(){
	if (this.checked) {
		$('#otherleasefield-footer').fadeIn('slow');
		//alert("Thanks for checking me");
	}
	else{
		$('#otherleasefield-footer').fadeOut('fast');
	}
});

$('input[name="otherorg-footer"]').change(function(){
	if (this.checked) {
		$('#otherorgfield-footer').fadeIn('slow');
		//alert("Thanks for checking me");
	}
	else{
		$('#otherorgfield-footer').fadeOut('fast');
	}
});

  

$(document).ready(function(){
    setTimeout(() => {
        var requestDemoVal = window.location.hash.substr(1);
        if(requestDemoVal == 'RequestDemo'){        
            $( "#requestDemo" ).trigger( "click" );
        }    
    }, 200);
    
    
			$('#demorequest-footer').on('submit', function(e){
				//Stop the form from submitting itself to the server.
				e.preventDefault();
				var name = $("#name-footer input").val();
				var email = $("#email-footer input").val();
				var designation = $("#designation-footer input").val();
				var companyname = $("#companyname-footer input").val();
				var country = $("#country-footer").val();
				var phone = $("#phone-footer input").val();
				var demo_for = $('input:checkbox:checked.demo_class').map(function(){ return this.value; }).get().join(",");
				var typeofbusiness = $('input:checkbox:checked.business_class').map(function(){ return this.value; }).get().join(",");
				var typeofleases = $('input:checkbox:checked.lease_class').map(function(){ return this.value; }).get().join(",");
				var typesoforg = $('input:checkbox:checked.org_class').map(function(){ return this.value; }).get().join(",");
				var contractvol = $("#contractvol-footer").val();
				var acceptance = $("#acceptance-footer").val();
				var comments = $("#comments-footer").val();
				
				// Returns successful data submission message when the entered information is stored in database.
				var dataString = 'name=' + name + '&company=' + companyname + '&designation=' + designation + '&email=' + email + '&country=' + country + '&phone=' + phone + '&demo_for=' + demo_for + '&typeofbusiness=' + typeofbusiness + '&typeofleases=' + typeofleases + '&typesoforg=' + typesoforg + '&contract_vol=' + contractvol + '&comments=' + comments + '&acceptcheck=' + acceptance;
				if (name == '' || companyname == '' || designation == '' || email == '' || country == ''){
				//alert("Please Fill All Fields");
				} else {
					//alert(dataString);
				// AJAX code to submit form.
					$.ajax({
						type: "POST",
						url: "db-queries/demo_request.php",
						data: dataString,
						cache: false,
						success: function(res) {
							//alert(res);
							if (res == "fail") {
								//alert(res);
								$('#captecha3').addClass('error');
								$('.error3').show();
							}
							else {
								//alert(res);
								resetformfooter();
								//$('#thankyounote-footer').fadeIn('slow');
								document.getElementsByName('demorequest-footer')[0].reset();
								refreshCaptcha3();
								$('#captecha3').removeClass('error');
								$('.error3').hide();
								return gtag_report_conversion('thank-you.php');
								//$('#captecha2').addClass('error');
								//$('.caperror').show('error');
							} 
						},
						error: function () {
							alert("There is some network problem, kindly check later!");
						}
						
					});
				}
				return false;
			});
			
});	
	
function refreshCaptcha3() {
	$("#captcha_code3").attr('src','includes/bot_captcha_code.php');
}
function refreshCaptcha4() {
	$("#captcha_code4").attr('src','includes/bot_captcha_code.php');
}	
</script>
<style>
#captcha_code3{border:#fff solid 3px !important; padding:5px;}
</style>
</body>
<script type="text/javascript"> _linkedin_partner_id = "482123"; window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || []; window._linkedin_data_partner_ids.push(_linkedin_partner_id); </script><script type="text/javascript"> (function(){var s = document.getElementsByTagName("script")[0]; var b = document.createElement("script"); b.type = "text/javascript";b.async = true; b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js"; s.parentNode.insertBefore(b, s);})(); </script> <noscript> <img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=482123&fmt=gif" /> </noscript>
</html>